
MAD <- function(x, na.rm = FALSE) fmedian(abs(x - fmedian(x, na.rm = na.rm)), na.rm = na.rm)

IQR <- function(x, na.rm = FALSE) {
  if(na.rm) return(stats::IQR(na_rm(x)))
  if(anyNA(x)) return(NA_real_)
  stats::IQR(x)
}

rob_beta_r2 <- function(y, x, ...) {
  res <- summary(lmrob(x ~ y, setting = "KS2014", ...))
  c(beta = res$coefficients[2,1], p = res$coefficients[2,4], r2 = res$r.squared)
}  

pretty_plot <- function(base.size = 14, caption.hjust = -0.1) {
  theme_minimal(base_size = base.size) +
  theme(panel.border = element_rect(fill = NA),
        axis.text = element_text(colour = "black"),
        strip.text = element_text(face = "bold", colour = "grey20"),
        plot.caption = element_text(hjust = caption.hjust, face= "italic"),
        legend.position = "right")
}

# Function to iteratively subtract the median (robust centering)
demedian <- function(x, g1, g2, iter = 100, TRA = "-") {
  cc <- which(complete.cases(x, g1, g2))
  if(length(cc) != length(x)) {
    x_copy <- x[cc]
    g1 <- g1[cc]
    g2 <- g2[cc]
  } else x_copy <- copy(x)
  g1 <- GRP(g1, sort = FALSE, call = FALSE)
  g2 <- GRP(g2, sort = FALSE, call = FALSE)
  for(i in seq_len(iter)) { # Not checking for convergence, but 100 iterations should be enough 
    fmedian(x_copy, g1, TRA = TRA, set = TRUE)
    fmedian(x_copy, g2, TRA = TRA, set = TRUE)
  }
  if(length(cc) != length(x)) {
    x[-cc] <- NA
    x[cc] <- x_copy
    return(x)
  } 
  x_copy 
}

# Scaling periodogram such that the sum of amplitudes matches half the variance
scale_pgram <- function(x, tovar = FALSE) {
  if(is.list(x)) {
    x$spec <- x$spec * (if(tovar) 2/x$n.used else 4/x$n.used)
  } else {
    x <- x * (if(tovar) 1/length(x) else 2/length(x)) # Because we only use n/2 (we don't return spectrum for the folding frequency)
  }
  x
}

# Turn a covariance matrix into a named vector
flatten_cov <- function(r) {
  ut <- upper.tri(r)
  rut <- r[ut] * 2 # giveing double weight to the off-diagnonal entries
  cn <- dimnames(r)[[2L]]
  nam <- outer(cn[-length(cn)], cn[-1L], FUN = paste, sep = ".")
  names(rut) <- nam[!lower.tri(nam)]
  return(c(diag(r), rut))
}

# Variable importance: difference in prediction error (MSE) in percentage terms
perc_inc_mse <- function(x) x$variable.importance / x$prediction.error * 100

# Compute permutation importance for a single predictor
my_perm_imp <- function(mod, y, nd) {
  k <- ncol(nd)
  n <- nrow(nd)
  res <- numeric(k)
  MSE <- mean((y - predict(mod, data = nd)$predictions)^2)
  for (i in 1:k) {
    d <- nd
    d[, i] <- d[, i][order(rnorm(n))]
    res[i] <- (mean((y - predict(mod, data = d)$predictions)^2)-MSE)/MSE * 100
  }
  names(res) <- colnames(nd)
  res
}

# Permutation importance of groups (topics) of predictors
my_perm_imp_group <- function(mod, y, nd, g, full.rand = FALSE) {
  k <- ncol(nd)
  n <- nrow(nd)
  res <- numeric(length(g))
  MSE <- mean((y - predict(mod, data = nd)$predictions)^2)
  for (i in seq_along(g)) {
    d <- nd
    if(full.rand) {
      for (j in g[[i]]) d[, j] <- d[, j][order(rnorm(n))]
    } else {
      d[, g[[i]]] <- d[order(rnorm(n)), g[[i]]]
    }
    res[i] <- (mean((y - predict(mod, data = d)$predictions)^2)-MSE)/MSE * 100
  }
  names(res) <- names(g)
  res
}

# Correlation Chart
chartcorr <- function(x, histogram = TRUE, method = c("pearson", "robust"), fit = c("lm", "smooth")) 
{
  x <- qM(x)
  cormeth <- method[1]
  panel.cor <- function(x, y, digits = 2, prefix = "", cex.cor, method = cormeth, ...) {
    usr <- par("usr")
    on.exit(par(usr))
    par(usr = c(0, 1, 0, 1))
    r <- switch(method, 
                pearson = pwcor(cbind(x, y), P = TRUE)[1,2, ], 
                robust = {
                  res <- summary(robustbase::lmrob(x ~ y, setting = "KS2014"))
                  coef <- res$coefficients
                  c(sqrt(res$r.squared) * (if(coef[2,1]>0) 1 else -1), coef[2,4])
                })
    txt <- format(c(r[1], 0.123456789), digits = digits)[1]
    txt <- paste(prefix, txt, sep = "")
    if (missing(cex.cor)) cex <- 0.5/strwidth(txt)
    Signif <- symnum(r[2], corr = FALSE, na = FALSE, 
                     cutpoints = c(0, 0.001, 0.01, 0.05, 0.1, 1), symbols = c("***", "**", "*", ".", " "))
    text(0.5, 0.5, txt, cex = cex) 
    text(0.8, 0.8, Signif, cex = cex, col = 2)
  }
  hist.panel = function(x, ...) {
    par(new = TRUE)
    hist(x, col = "light gray", probability = TRUE, axes = FALSE, 
         main = "", breaks = "FD", border = NA)
    lines(density(x, na.rm = TRUE), col = "red", lwd = 1)
    rug(x)
  }
  panel.lm <- function (x, y, col = par("col"), bg = NA, pch = par("pch"), 
                        cex = 1, col.smooth = 2, span = 2/3, iter = 3, meth = cormeth, ...) 
  {
    points(x, y, pch = pch, col = col, bg = bg, cex = cex)
    ok <- is.finite(x) & is.finite(y)
    if (any(ok))  abline(switch(meth,
                                pearson = lm(y[ok] ~ x[ok]), 
                                robust = robustbase::lmrob(y[ok] ~ x[ok], setting = "KS2014")
    ), col = col.smooth, ...)
  }
  if (histogram) 
    pairs(x, gap = 0, lower.panel = switch(fit[1], lm = panel.lm, smooth = panel.smooth),
          upper.panel = panel.cor, diag.panel = hist.panel, font.labels = 2)
  else pairs(x, gap = 0, lower.panel = switch(fit[1], lm = panel.lm, smooth = panel.smooth), 
             upper.panel = panel.cor)
}