#########################################
# Africa's Great Moderation
# ---------------------------------------
# Replication Code for Section 5: 
# Structural Factors
# ---------------------------------------
# By Sebastian Krantz (IfW Kiel)
#########################################

# This analysis was conducted using GNU R 4.1.0 for Windows

# Loading Packages
library(collapse)      # v1.8.9
library(data.table)    # v1.14.0
library(magrittr)      # v2.0.1
library(ranger)        # v0.12.1
library(kableExtra)    # v1.3.4
# These are quite stable packages, I expect the code to run also with future versions

source("Code/functions.R")

###############################
# Cross-Section of 49 Countries
###############################

cs_data_agg <- readRDS("Data/Processed/cs_data_agg.rds")

# Preparing data for imputation
X <- cs_data_agg %>% fselect(-ISO3) %>% 
  ftransform(
    ht05_ht_colonial = substr(as.character(ht05_ht_colonial), 4, 100) %>%
      recode_char(British = "British", French = "French", default = "Other") %>%
      factor(levels = c("Other", "British", "French")) %>% 
      setLabels(vlabels(ht05_ht_colonial)),
    ht05_ht_region = fifelse(ht05_ht_region == "4. Sub-Saharan Africa", 1, 0) %>% 
      setLabels(vlabels(ht05_ht_region)))

# Uncomment to do imputation
# # Checking number of missing predictors per country
# rowSums(is.na(X)) %>% setNames(cs_data_agg$ISO3) %>% sort()
# # Case weight = number of non-missing predictors
# cwt <- rowSums(!is.na(X))
# 1-sum(cwt) / (ncol(X)*length(cwt)) # Total prop missing in datase
# # Now imputing the data
# library(missRanger)    # v2.1.3
# X_imp <- missRanger(X, maxiter = 100L, num.trees = 10000L, pmm.k = 5L, 
#                     case.weights = cwt, seed = 101, returnOOB = TRUE)
# # Out-of-Bag R-Squared
# qsu(1-attr(X_imp, "oob"))
# qsu(X_imp, vlabels = vlabels) # Summarizing imputed data
# saveRDS(X_imp, "Data/Processed/cs_data_agg_imp.rds")

# Now doing analysis with the imputed data
X_imp <- readRDS("Data/Processed/cs_data_agg_imp.rds")
# Turning the data into a matrix, expanding the colonial origin factor into British and French dummies
# names(X_imp) <- vlabels(X_imp)
# X_imp <- model.matrix(~., X_imp)[, -1L]
# colnames(X_imp) <- gsub("`", "", colnames(X_imp))
qsu(X_imp)
# This shows correlations between all variables
# cor(X_imp) %>% `diag<-`(NA) %>% qDT("var") %>% melt(1, na.rm = TRUE) %>% View()

# Summary statistics of predictors by category:
namlab(X, N = TRUE)
su <- function(x) cbind(qsu(x, vlabels = vlabels), Median = fmedian(x), Ndist = fndistinct(x))[, .c(N, Ndist, Mean, Median, SD, Min, Max)]
cs_topics <- list("Institutions" = .c(qog_iiag_gov, WGI_PC1, qog_ffp_hr, ht05_fh_ipolity2, ht05_FREEDOMAV, qog_p_durable, ht05_ht_colonial, qog_ti_cpi),
                  "Business Environment" = .c(IC_BUS_EASE_DFRN_XQ_DB1719, LP_LPI_OVRL_XQ, IEF, qog_prp_prp),
                  "Production Shares" = .c(NV_AGR_TOTL_ZS, NV_IND_TOTL_ZS),
                  "Climate & Agriculture" = .c(AG_LND_CROP_ZS, AG_YLD_CREL_KG, ei_cckp_rain, ei_cckp_temp, cid_kgptr, ei_fao_luagrirreqcrop, cid_irrsuit1, cid_soilsui1),
                  "Trade Intensity and Composition" = .c(TG_VAL_TOTL_GD_ZS, TX_VAL_AGRI_ZS_UN, TX_VAL_MANF_ZS_UN, TX_VAL_MMTL_ZS_UN, TX_VAL_MRCH_HI_ZS, TX_VAL_MRCH_OR_ZS, TM_VAL_MRCH_HI_ZS),
                  "Trade Diversification" = .c(NHI_partner, TI_partner, NHI_product, TI_product),
                  "Exchange Rate and ToT" = .c(E_GROWTH, E_GROWTH_MAD, TT_PRI_MRCH_XD_WD, TOT_GROWTH, TOT_GROWTH_MAD),
                  "Financial & Aid Flows" = .c(BX_KLT_DINV_WD_GD_ZS, FDI_GDP_DIFF_MAD, BX_TRF_PWKR_DT_GD_ZS, REM_GDP_DIFF_MAD, DT_ODA_ODAT_GN_ZS),
                  "Financial Sector" = .c(FM_LBL_BMNY_GD_ZS, BMNY_GROWTH, BMNY_GROWTH_MAD, FS_AST_PRVT_GD_ZS, FD_RES_LIQU_AS_ZS, FX_OWN_TOTL_ZS),
                  "Debt & Reserves" = .c(GGXWDG_NGDP, DT_DOD_DECT_GN_ZS, DT_TDS_DECT_GN_ZS, FI_RES_TOTL_MO),
                  "Population" = .c(SP_POP_TOTL, SP_POP_GROW, SP_URB_TOTL_IN_ZS, EN_POP_DNST, SP_POP_DPND, SM_POP_TOTL_ZS), 
                  "Health" = .c(SP_DYN_LE00_IN, SP_DYN_IMRT_IN, SH_STA_BASS_ZS, ht05_mal94p, ht05_ME),
                  "Education" = .c(qog_egov_hci, ht05_MeanYearSch, ht05_ExpYearSch, SE_ADT_LITR_ZS, ht05_EURFRAC),
                  "Natural Disasters & Conflict" = .c(ei_emdat_nhome, ei_emdat_ndeath, ei_emdat_damage, acled_fatalities, qog_svs_ind, qog_cspf_sfi), 
                  "Geography & Accessibility" = .c(ht05_LNFRINSTEX, cid_lcr100km, ht05_ht_region, ht05_LANDLOCK, ht05_dis_int, ht05_lat, ht05_lon),
                  "Natural Resources" = .c(NY_GDP_TOTL_RT_ZS, NY_GDP_PETR_RT_ZS),
                  "Poverty & Inequality" = .c(SI_POV_DDAY, SI_POV_GAPS, SI_POV_GINI), 
                  "Religion & Ethnicity" = .c(ht05_lp_muslim80, ht05_lp_protmg80, qog_al_religion2000, qog_al_ethnic2000), 
                  "Others" = .c(qog_dr_ig, qog_undp_hdi, sm97_GDPSH60, SL_GDP_PCAP_EM_KD, EG_ELC_ACCS_ZS, NGSD_NGDP))

# All Indicators
X %>% get_vars(unlist(cs_topics)) %>% su()
X %>% get_vars(setdiff(names(.), unlist(cs_topics))) %>% namlab() # Should be empty

# Table 17: Institutions has 9 indicators because of the 2 dummies created from the colonial origin factor
vlengths(cs_topics) %>% qDF(TRUE) %>% 
  set_names(c("Topic", "N. Indicators")) %>% 
  kbl("latex", booktabs = TRUE) %>% 
  save_kable("Tables/CS_Topics.tex")

sum(vlengths(cs_topics))

# Full Table (Appendix): Also replace Colonial Origin in Institutions with the 2 dummies in the X_imp matrix
lapply(cs_topics, get_vars, x = X) %>% lapply(su) %>% 
  kbl("latex", digits = 2, linesep = "") %>% 
  save_kable("Tables/CS_Indicators.tex")

# Generating Outcome Measures
cs_data <- readRDS("Data/Processed/cs_data.rds")

cs_outcomes <- cs_data %>% 
  roworder(ISO3, Date) %>% 
  fgroup_by(ISO3) %>% 
  fmutate(GDPPCG = fgrowth(NGDPRPC), 
          GDPPCG_WB = fgrowth(NY_GDP_PCAP_KD), 
          INFL = PCPIPCH,
          INFL_WB = fgrowth(FP_CPI_TOTL)) %>% 
  fsummarise(across(c(GDPPCG, GDPPCG_WB, INFL, INFL_WB), 
                    list(fmedian, mad, IQR, fsd), na.rm = TRUE)) %>% 
  fsubset(ckmatch(cs_data_agg$ISO3, ISO3))

qsu(cs_outcomes)

# Getting list of topic labels (needed for topics ranking)
topics_labs <- lapply(cs_topics, function(x) vlabels(X)[x])

# PCA of all indicators in each topic
topics_pca <- topics_labs %>% 
  inset2(1L, setdiff(extract2(., 1L), "Colonial Origin")) %>% # Excluding colonial origin dummies from Institutions
  # inset2(1L, c(setdiff(extract2(., 1L), "Colonial Origin"), paste0("Colonial Origin", c("British", "French")))) %>%
  lapply(function(x) prcomp(fscale(X_imp[, x]), center = FALSE))

# Adding dummy information
topics_labs$Institutions["ht05_ht_colonial"] <- "Colonial OriginFrench"
topics_labs$Institutions["ht05_ht_colonial_br"] <- "Colonial OriginBritish"

# Summarising PCA's
topics_pca %>% lapply(summary)

# Percentage of variance explained by first 2 PCS (Appendix Table)
topics_pca %>% 
  lapply(function(x) c(list(length(x$sdev)), as.list(proportions(x$sdev^2)[1:2] * 100))) %>% 
  rbindlist(idcol = "Topic") %>% 
  frename(V1 = N, V2 = PC1, V3 = PC2) %>% 
  fmutate(Total = PC1 + PC2) %>% 
  # num_vars() %>% fmean()
  kbl("latex", digits = 2, booktabs = TRUE, linesep = "") %>% 
  save_kable("Tables/CS_PC12_PVE.tex")
  
# Getting PCA data
X_imp_pca <- topics_pca %>% lapply(function(y) y$x[, 1:2]) %>% do.call(what = cbind) %>% 
  setColnames(paste(rep(names(topics_labs), each = 2), colnames(.)))

topics_labs_pca <- names(topics_labs) %>% setNames(object = as.list(.)) %>% lapply(paste, c("PC1", "PC2"))
# Check 
all(colnames(X_imp_pca) == unlist(topics_labs_pca))

# Dependent variables
depvars <- cs_outcomes %>% fselect(-ISO3) %>% unclass()


# Running Assessment --------------------------------------------------------

# Iterating over dependent variables
for (ynam in names(depvars)) {
  
print(ynam)
  
# Fitting RF Model: Ranking of individual Predictors
y <- depvars[[ynam]]

# If any missing: impute with data from other source...
if(anyNA(y)) {
  message(sprintf("Some countries miss the outcome %s doing a linear prediction with data from other source...", ynam))
  matches <- sub("WB_", "", names(depvars)) %in% sub("WB_", "", ynam)
  y_oth <- depvars[[which(matches & names(depvars) != ynam)]]
  y[is.na(y)] <- predict(lm(y ~ y_oth))[is.na(y)]
  rm(y_oth, matches)
}

model <- ranger(y = y, x = X_imp, num.trees = 1e5, 
                min.node.size = 1, mtry = 3, splitrule = "variance",  
                seed = 100, importance = 'permutation') 
print(model)
# oldpar <- par(mai = c(5.52, 0.82, 0.82, 0.42))
# importance(model) %>% sort() %>% barplot(las = 2)
# par(oldpar)

oldpar <- par(mai = c(0.8, 4, 0.62, 0.42), mgp = c(2.3, 1, 0))
top30 <- perc_inc_mse(model) %>% sort(decreasing = TRUE) %>% extract(1:30)
xmax <- as.integer(ceiling(max(top30)))
rev(top30) %>% rnm(gsub, pat = "^`|`$", rep = "") %>% 
  barplot(horiz = TRUE, las = 2, col = "orange", border = NA, axes = FALSE,
          xlab = "% Increase in Mean Squared Error from Permuting the Variable", main = NULL) 
axis(1, at = seq(0L, xmax, 1L), labels = TRUE) 
if(xmax >= 1L) abline(v = seq(1L, xmax, 1L), lty = 9, col = "grey50")
if(xmax >= 2L) abline(v = seq(2L, xmax, 2L), lty = 3)
mysubtitle = paste0("Top 30 Predictors from a RF Model with ", ncol(X_imp)," Variables, ", model$num.trees/1000, 
                    "k Trees and 3 Variables per Split. OOB R-Squared = ", round(model$r.squared * 100, 1), "%.")
mtext(side = 3, line = 2, at = -0.07, adj = 0.31, padj = 2, cex = 1, mysubtitle)
rm(top30, xmax)
par(oldpar)                  

dev.copy(pdf, sprintf("Figures/RF_%s_results.pdf", ynam), width = 10.27, height = 8)
dev.off()


# Importance of groups of predictors

# Method 1: Permuting groups of predictors in the full model
set.seed(100)
topic_imp <- my_perm_imp_group(model, y, X_imp, topics_labs)
# barplot(sort(topic_imp), las = 2)

# Method 2: Fitting alternative models without the group, using optimal settings. 
full_mod_opt <- ranger(y = y, x = X_imp, num.trees = 10000, seed = 100,
                       min.node.size = 1, mtry = 8, splitrule = "variance") 
print(full_mod_opt)
topic_imp2 <- topic_imp
for (i in seq_along(topic_imp)) {
  topic_imp2[i] <- ranger(y = y, x = X_imp[, unlist(topics_labs[-i])], num.trees = 10000, seed = 100,
                          min.node.size = 1, mtry = 8, splitrule = "variance")$prediction.error 
}
topic_imp2 <- (topic_imp2 - full_mod_opt$prediction.error)/full_mod_opt$prediction.error * 100

# Method 3: Same, but partialling out predictors first...
topic_imp3 <- topic_imp
for (i in seq_along(topic_imp)) {
  topic_imp3[i] <- ranger(y = y, x = fhdwithin(X_imp[, unlist(topics_labs[-i])], X_imp[, topics_labs[[i]]]), num.trees = 10000, seed = 100,
                          min.node.size = 1, mtry = 8, splitrule = "variance")$prediction.error 
}
topic_imp3 <- (topic_imp3 - full_mod_opt$prediction.error)/full_mod_opt$prediction.error * 100

# Summarizing:
cbind(topic_imp, rank = frank(-topic_imp), topic_imp2, rank2 = frank(-topic_imp2), topic_imp3, rank3 = frank(-topic_imp3)) %>% 
  qDF("Topic") %>% ftransform(OVRL_Rank = (rank + rank2 + rank3) / 3) %>% roworder(OVRL_Rank) %>% 
  kbl("latex", digits = 2, booktabs = TRUE, linesep = "") %>% 
  save_kable(sprintf("Tables/RF_%s_results.tex", ynam))


# # Tuning full model...
# ptm <- proc.time()
# library(caret)
# 
# grid <-  expand.grid(mtry = 3:20, min.node.size = 10:1, splitrule = c("variance", "extratrees", "maxstat"))
# fitControl <- trainControl(method = "CV", number = 5) # verboseIter = TRUE
# 
# fit <- train(
#   x = X_imp,
#   y = y,
#   method = 'ranger',
#   num.trees = 10000,
#   tuneGrid = grid,
#   trControl = fitControl
# )
# print(fit)
# print(proc.time() - ptm) # ~2.4 seconds
# # Best: mtry = 8, splitrule = "variance", min.node.size = 1


# PCA Models
mod_pca <- ranger(y = y, x = X_imp_pca, num.trees = 1e4, 
                  min.node.size = 1, mtry = 8, splitrule = "variance", # Optimal tuning parameters (see below)
                  seed = 100, importance = 'permutation') 
print(mod_pca)
# oldpar <- par(mai = c(5.52, 0.82, 0.82, 0.42))
# importance(mod_pca) %>% sort() %>% barplot(las = 2)
# par(oldpar)

oldpar <- par(mai = c(0.8, 4, 0.62, 0.42), mgp = c(2.3, 1, 0))
top30 <- perc_inc_mse(mod_pca) %>% sort(decreasing = TRUE) %>% extract(1:30)
xmax <- as.integer(ceiling(max(top30)))
rev(top30) %>% rnm(gsub, pat = "^`|`$", rep = "") %>% 
  barplot(horiz = TRUE, las = 2, col = "orange", border = NA, axes = FALSE,
          xlab = "% Increase in Mean Squared Error from Permuting the Variable", main = NULL) 
axis(1, at = seq(0L, xmax, 1L), labels = TRUE) 
if(xmax >= 1L) abline(v = seq(1L, xmax, 1L), lty = 9, col = "grey50")
if(xmax >= 2L) abline(v = seq(2L, xmax, 2L), lty = 3)
mysubtitle = paste0("Top 30 Predictors from a RF Model with ", ncol(X_imp_pca)," Variables, ", mod_pca$num.trees/1000, 
                    "k Trees and 3 Variables per Split. OOB R-Squared = ", round(mod_pca$r.squared * 100, 1), "%.")
mtext(side = 3, line = 2, at = -0.07, adj = 0.31, padj = 2, cex = 1, mysubtitle)
rm(top30, xmax)
par(oldpar)                  

dev.copy(pdf, sprintf("Figures/RF_%s_results_pca.pdf", ynam), width = 10.27, height = 8)
dev.off()

# Method 1: Permuting groups of predictors in the full model
set.seed(100)
topic_imp_pca <- my_perm_imp_group(mod_pca, y, X_imp_pca, topics_labs_pca)
# barplot(sort(topic_imp_pca), las = 2)

# Method 2: Fitting alternative models without the group, using optimal settings. 
topic_imp_pca2 <- topic_imp_pca
for (i in seq_along(topic_imp_pca)) {
  topic_imp_pca2[i] <- ranger(y = y, x = X_imp_pca[, unlist(topics_labs_pca[-i])], num.trees = 10000, seed = 100,
                              mtry = 8, min.node.size = 1, splitrule = "variance")$prediction.error 
}
topic_imp_pca2 <- (topic_imp_pca2 - mod_pca$prediction.error)/mod_pca$prediction.error * 100

# Method 3: Same, but partialling out predictors first...
topic_imp_pca3 <- topic_imp_pca
for (i in seq_along(topic_imp_pca)) {
  topic_imp_pca3[i] <- ranger(y = y, x = fhdwithin(X_imp_pca[, unlist(topics_labs_pca[-i])], X_imp_pca[, topics_labs_pca[[i]]]), num.trees = 10000, seed = 100,
                              mtry = 8, min.node.size = 1, splitrule = "variance")$prediction.error 
}
topic_imp_pca3 <- (topic_imp_pca3 - mod_pca$prediction.error)/mod_pca$prediction.error * 100

# Summarizing:
cbind(topic_imp_pca, rank = frank(-topic_imp_pca), topic_imp_pca2, rank2 = frank(-topic_imp_pca2), 
      topic_imp_pca3, rank3 = frank(-topic_imp_pca3)) %>% 
  qDF("Topic") %>% ftransform(OVRL_Rank = (rank + rank2 + rank3) / 3) %>% roworder(OVRL_Rank) %>% 
  kbl("latex", digits = 2, booktabs = TRUE, linesep = "") %>% 
  save_kable(sprintf("Tables/RF_%s_results_pca.tex", ynam))


# # Tuning PCA full model...
# ptm <- proc.time()
# library(caret)
# 
# grid <-  expand.grid(mtry = 3:10, min.node.size = 10:1, splitrule = c("variance", "extratrees", "maxstat"))
# fitControl <- trainControl(method = "CV", number = 5) # verboseIter = TRUE
# 
# fit <- train(
#   x = X_imp_pca,
#   y = y,
#   method = 'ranger',
#   num.trees = 1000,
#   tuneGrid = grid,
#   trControl = fitControl
# )
# print(fit)
# print(proc.time() - ptm) 
# # Best: mtry = 8, splitrule = "extratrees", min.node.size = 1
# View(fit$results)
# # but splitrule = "variance" gives almost the same performance so we stick with it..

}

######################################
# Panel of Differences of 49 Countries
######################################


# Loading pre-processed panel data
.c(p_data_agg, p_data_agg_diff) %=% readRDS("Data/Processed/p_data_agg_diff.rds")

# Panel Outcome Data
p_outcomes <- cs_data %>% 
  roworder(ISO3, Date) %>% 
  fmutate(H2 = Date > as.Date("2004-01-01")) %>%
  fgroup_by(ISO3) %>% 
  fmutate(GDPPCG = fgrowth(NGDPRPC), 
          GDPPCG_WB = fgrowth(NY_GDP_PCAP_KD), 
          INFL = PCPIPCH,
          INFL_WB = fgrowth(FP_CPI_TOTL)) %>% 
  fgroup_by(ISO3, H2) %>%
  fsummarise(across(c(GDPPCG, GDPPCG_WB, INFL, INFL_WB), 
                    list(fmedian, mad, IQR, fsd), na.rm = TRUE)) %>% 
  fsubset(ISO3 %in% p_data_agg_diff$ISO3) 

qsu(p_outcomes)

# Differencing Outcome Data
p_outcomes_diff <- p_outcomes %>% 
  fmutate(id = 1) %>% 
  D(by = ~ ISO3, t = ~ H2, stubs = FALSE) %>% 
  fsubset(is.finite(id), -id) %>% 
  get_vars(varying(.) & fnobs(.) > 30) %>%
  fsubset(ckmatch(p_data_agg_diff$ISO3, ISO3)) %>% 
  add_stub("_diff", FALSE, cols = -1L)

qsu(p_outcomes_diff)

# Check:
identical(p_outcomes_diff$ISO3, p_data_agg_diff$ISO3)

X <- p_data_agg_diff %>% fselect(-ISO3)

# Uncomment to do imputation
# # Checking number of missing predictors per country
# rowSums(is.na(X)) %>% setNames(p_data_agg_diff$ISO3) %>% sort()
# # Case weight = number of non-missing predictors
# cwt <- rowSums(!is.na(X))
# 1-sum(cwt) / (ncol(X)*length(cwt)) # Total prop missing in dataset
# # Now imputing the data
# library(missRanger)    # v2.1.3
# X_imp <- missRanger(X, maxiter = 100L, num.trees = 10000L, pmm.k = 5L, 
#                     case.weights = cwt, seed = 101, returnOOB = TRUE)
# # Out-of-Bag R-Squared
# qsu(1-attr(X_imp, "oob"))
# qsu(X_imp, vlabels = vlabels) # Summarizing imputed data
# saveRDS(X_imp, "Data/Processed/p_data_agg_diff_imp.rds")

# Now doing analysis with the imputed data
X_imp <- readRDS("Data/Processed/p_data_agg_diff_imp.rds")
# Turning the data into a matrix, expanding the colonial origin factor into British and French dummies
# names(X_imp) <- vlabels(X_imp)
# X_imp <- model.matrix(~., X_imp)[, -1L]
# colnames(X_imp) <- gsub("`", "", colnames(X_imp))
dim(X_imp)
qsu(X_imp)
# This shows correlations between all variables
# cor(X_imp) %>% `diag<-`(NA) %>% qDT("var") %>% melt(1, na.rm = TRUE) %>% View()

# Indicator topics in panel analysis
p_topics <- lapply(cs_topics, function(x) tolower(x) %>% intersect(names(p_data_agg_diff))) %>% extract(vlengths(.) > 0)
sum(vlengths(p_topics))
setdiff(names(p_data_agg_diff), unlist(p_topics))
p_topics$Institutions = c(p_topics$Institutions, "qog_p_polity2")

# Getting list of topic labels (needed for topics ranking)
topics_labs <- lapply(p_topics, function(x) vlabels(X)[x])

# PCA of all indicators in each topic
topics_pca <- topics_labs %>% 
  lapply(function(x) prcomp(fscale(X_imp[, x]), center = FALSE))

# Summarising PCA's
topics_pca %>% lapply(summary)

# Percentage of variance explained by first 2 PCS (Appendix Table)
topics_pca %>% 
  lapply(function(x) c(list(length(x$sdev)), as.list(proportions(x$sdev^2)[1:2] * 100))) %>% 
  rbindlist(idcol = "Topic") %>% 
  frename(V1 = N, V2 = PC1, V3 = PC2) %>% 
  fmutate(Total = PC1 + PC2) %>% 
  # num_vars() %>% fmean()
  kbl("latex", digits = 2, booktabs = TRUE, linesep = "") %>% 
  save_kable("Tables/P_PC12_PVE.tex")


# Combining PC12 Data
X_imp_pca <- topics_pca %>% lapply(function(y) y$x[, 1:2]) %>% do.call(what = cbind) %>% 
  setColnames(paste(rep(names(topics_labs), each = 2), colnames(.)))

topics_labs_pca <- names(topics_labs) %>% setNames(object = as.list(.)) %>% lapply(paste, c("PC1", "PC2"))
# Check 
all(colnames(X_imp_pca) == unlist(topics_labs_pca))

# Dependent variables
depvars <- p_outcomes_diff %>% fselect(-ISO3) %>% unclass()
names(depvars)

# Now go back to line 157 to run the analysis in differences ...

