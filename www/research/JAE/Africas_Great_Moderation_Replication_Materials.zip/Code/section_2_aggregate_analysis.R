#########################################
# Africa's Great Moderation
# ---------------------------------------
# Replication Code for Section 2: 
# Aggregate Relationships and Trends +
# Additional Tables/Figures in Appendix C 
# ---------------------------------------
# By Sebastian Krantz (IfW Kiel)
#########################################

# This analysis was conducted using GNU R 4.1.0 for Windows

# Loading Packages
library(collapse)      # v1.8.9
library(data.table)    # v1.14.0
library(magrittr)      # v2.0.1
library(africamonitor) # v0.2.1
library(ggplot2)       # v3.3.5
library(kableExtra)    # v1.3.4
library(robustbase)    # 0.93-6
# {ggrepel} v0.9.1 and {roll} v1.1.6 are also used for some figures / computations
# These are quite stable packages, I expect the code to run also with future versions

# Loading Data and Functions
# (Data Series are taken from World Bank and IMF databases and mostly available through the africamonitor API)
DATA <- readRDS("Data/MACRO_DATA.rds") 
source("Code/functions.R")


# Describing the data
DATA_labels <- namlab(DATA, N = TRUE, Ndistinct = TRUE, class = TRUE)

# Computing per-capita GDP growth using IMF WEO (October 2021) or World Bank WDI data
DATA[Year < 2020, .c(GDPCGR, GDPCGR_WB) := fgrowth(.(NGDPRPC, NY.GDP.PCAP.KD), g = ISO3, t = Year)] 

# Comparing the data
descr(DATA, cols = .c(GDPCGR, GDPCGR_WB))
DATA %T>% with(plot(GDPCGR, GDPCGR_WB)) %$% pwcor(GDPCGR, GDPCGR_WB)
abline(0, 1, col = "red")

# Computing CPI inflation using IMF WEO (October 2021) or World Bank WDI data
DATA[Year < 2020, .c(INFL, INFL_WB) := .(PCPIPCH, fgrowth(FP.CPI.TOTL, g = ISO3, t = Year))]                                

# Comparing the data
descr(DATA, cols = .c(INFL, INFL_WB))
DATA %>% fselect(INFL, INFL_WB) %>% replace_outliers(c(-50, 50)) %T>% 
  with(plot(INFL, INFL_WB)) %$% pwcor(INFL, INFL_WB)
abline(0, 1, col = "red")

# Indicate data source
source <- "Data Source: IMF World Economic Outlook, October 2021"

# To redo all analysis with World Bank data (for some Appendix Figures)
# DATA[, .c(GDPCGR, INFL) := list(GDPCGR_WB, INFL_WB)]
# source <- "Data Source: World Development Indicators, Accessed November 2021"

# Computing Area Variable
DATA[, Area := structure(ISO3 %!in% am_countries$ISO3 + 1L, 
                         levels = c("Africa", "ROW"), 
                         class = "factor")]
DATA %$% fndistinct(ISO3, Area)
DATA[, Income := factor(Income, levels = c("Low income", "Lower middle income", "Upper middle income", "High income"))]
DATA %$% fndistinct(ISO3, Income)

# Growth Volatility and Average Growth

# Summarizing the data over the 1990-2019 period using robust volatility measures
summ_stats <- DATA %>% 
  fsubset(!is.na(Income) & (is.finite(GDPCGR) | is.finite(INFL)) & Year >= 1990 & Year < 2020, 
          Country, ISO2, ISO3, Region, Income, Area, GDPCGR, INFL) %>% 
  fgroup_by(Country:Area) %>% 
  fsummarise(across(c(GDPCGR, INFL), 
                    list(N = fnobs, median = fmedian, MAD = MAD, IQR = IQR), 
                    na.rm = TRUE, .transpose = TRUE))

# Checking countries with less than 20 observations for either growth or inflation
summ_stats %>% fsubset(GDPCGR_N < 20L | INFL_N < 20L, Country, ISO3, GDPCGR_N, INFL_N) 
# Removing these countries
summ_stats %<>% fsubset(GDPCGR_N >= 20L & INFL_N >= 20L, -GDPCGR_N, -INFL_N)

qtab(summ_stats$Area)
setdiff(am_countries$ISO3, summ_stats$ISO3) # African countries removed

# Summary Stats
qsu(summ_stats, ~ Area, cols = is.numeric)

# Volatility in African Countries: Appendix Table C1
summ_stats %>% 
  fsubset(Area == "Africa", ISO3, Country, Income, GDPCGR_median:INFL_IQR) %>%
  fmutate(Income = sub(" income", "", Income)) %>% 
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "")

# Appendix Table C2
Table_C2 <- rbind(
  summ_stats[, c(list(N = .N), lapply(num_vars(.SD), median)), by = Area], 
  summ_stats[, c(list(N = .N), lapply(num_vars(.SD), median)), by = .(Area, Income)], fill = TRUE) %>% 
  colorder(Area, Income) %>% 
  roworder(Area, Income, na.last = FALSE) %>%
  as_character_factor() %>% 
  ftransform(Area = replace_NA(Income, Area), Income = NULL) 

print(Table_C2)

# Latex export of Table C2
Table_C2 %>%
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "") %>% 
  row_spec(c(1L, 6L), bold = TRUE) %>% 
  add_indent(c(2:5, 7:10))
  
# Empirical Relationship

# Appendix Table C3
Table_C3 <- rbind(
  summ_stats[, as.list(c(N = .N, 
                         rob_beta_r2(GDPCGR_median, GDPCGR_MAD), 
                         rob_beta_r2(INFL_median, INFL_MAD))), by = Area], 
  summ_stats[, if(.N > 4) as.list(c(N = .N, 
                         rob_beta_r2(GDPCGR_median, GDPCGR_MAD), 
                         rob_beta_r2(INFL_median, INFL_MAD))), by = .(Area, Income)], fill = TRUE) %>% 
  colorder(Area, Income) %>% 
  roworder(Area, Income, na.last = FALSE) %>%
  as_character_factor() %>% 
  add_stub("growth_", cols = 4:6) %>% 
  add_stub("inflation_", cols = 7:9) %>% 
  ftransform(Area = replace_NA(Income, Area), Income = NULL) 

print(Table_C3)

# Latex export of Table C3
Table_C3 %>%
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "") %>% 
  row_spec(c(1L, 5L), bold = TRUE) %>% 
  add_indent(c(2:4, 6:fnrow(Table_C3)))

# For Figure C8
growth_stats_long <- summ_stats %>% 
  get_vars("_N$|_IQR$", regex = TRUE, invert = TRUE) %>% 
  melt(cat_vars(., "names"), variable.factor = FALSE, na.rm = TRUE) %>%
  ftransform(statistic = fifelse(endsWith(variable, "MAD"), "Median Absolute Deviation", "Median"), 
             variable = structure(startsWith(variable, "INFL") + 1L, 
                           levels = c("GDP per Capita Growth", "CPI Inflation"), 
                           class = c("ordered", "factor"))) %>%
  colorder(value, pos = "end")

# Figure C8
growth_stats_long %>% 
  dcast(... ~ statistic) %>%
  ggplot(aes(x = Median, y = `Median Absolute Deviation`, colour = Area)) + 
  geom_point() + geom_smooth(method = "lmrob", se = TRUE, alpha = 0.2) + 
  ggrepel::geom_text_repel(aes(label = ISO2), show.legend = FALSE) + # ggrepel v0.9.1
  facet_wrap("variable", scales = "free") +
  scale_colour_manual(values = c("grey20", "orange")) +
  scale_x_continuous(n.breaks = 10) +
  scale_y_log10(n.breaks = 10, limits = function(x) replace(x, x > 30, 30)) +  
  annotation_logticks(sides = "l") +
  labs(title = "Real GDP per Capita Growth and CPI Inflation, 1990-2019", 
       y = "Median Absolute Deviation", x = "Median",
       caption = source) +
  pretty_plot(caption.hjust = -0.05)

dev.copy(pdf, "Figures/Growth_Median_MAD.pdf", width = 11.27, height = 5.3)
dev.off()


# Figure C9: LHS
summ_stats %>% 
  fsubset(Area == "Africa",
          `Median Growth` = GDPCGR_median, 
          `MAD Growth` = GDPCGR_MAD, 
          `Median Inflation` = INFL_median, 
          `MAD Inflation` = INFL_MAD) %>% 
  chartcorr(method = "robust") 

dev.copy(pdf, "Figures/Growth_Stats_Chartcorr.pdf", width = 7, height = 5)
dev.off()


# 10-Year Rolling Estimates
roll_stats <- DATA %>% 
  fsubset(!is.na(Income) & (is.finite(GDPCGR) | is.finite(INFL)) & Year >= 1980 & Year < 2020, 
          Country, ISO2, ISO3, Region, Income, Area, Year, GDPCGR, INFL, 
          GDP = NY.GDP.MKTP.CD, POP = SP.POP.TOTL) %>% 
  roworder(ISO3, Year) %>%
  fgroup_by(Country:Area) %>% 
  fmutate(across(c(GDPCGR, INFL), list(
                      median = function(x) frollapply(x, 10, median), 
                      MAD = function(x) frollapply(x, 10, MAD), 
                      IQR = function(x) frollapply(x, 10, IQR)), .transpose = TRUE), 
          across(c(GDPCGR_median, INFL_median), list(N = fnobs), .names = TRUE),
          across(c(GDP, POP), frollmean, 10)) %>%
  fungroup()

# Checking countries with less than 15 observations for either growth or inflation
roll_stats %>% fsubset(GDPCGR_median_N < 15L | INFL_median_N < 15L, 
                       Country, ISO3, GDPCGR_median_N, INFL_median_N) %>% funique()
# Removing these countries
roll_stats %<>% fsubset(GDPCGR_median_N >= 15L & INFL_median_N >= 15L, 
                        -GDPCGR_median_N, -INFL_median_N)

roll_stats %$% ffirst(Area, ISO3) %>% qtab()
setdiff(am_countries$ISO3, roll_stats$ISO3) # African countries removed

# Aggregation using quartiles: for Figure 1
roll_stats_summ <- roll_stats %>% 
  fsubset(Year >= 1990, Area, Year, GDPCGR_median, 
          INFL_median, GDPCGR_MAD, INFL_MAD) %>% 
  fgroup_by(Area, Year) %>%
  fmutate(N = GRPN()) %>%
  {list(Median = fmedian(.), P25 = fnth(., 0.25), P75 = fnth(., 0.75))} %>% 
  rbindlist(idcol = "Quantile") %>% 
  colorder(Year, N, pos = "after")

print(roll_stats_summ)

# Figure 1 and C4
roll_stats_summ %>% melt(1:4) %>%
  fmutate(variable = set_attr(variable, "levels", 
            recode_char(levels(variable),
                   GDPCGR_median = "Median: GDP per Capita Growth", 
                   INFL_median = "Median: CPI Inflation", 
                   GDPCGR_MAD  = "MAD: GDP per Capita Growth", 
                   INFL_MAD = "MAD: CPI Inflation"))) %>%
  ggplot(aes(x = Year, y = value, colour = Area, linetype = Quantile)) +
  geom_line() + 
  facet_wrap( ~ variable, scales = "free_y") +
  scale_colour_manual(values = c("grey20", "orange")) +
  scale_x_continuous(n.breaks = 6) +
  scale_y_continuous(n.breaks = 10) +
  labs(title = "GDP per Capita Growth and CPI Inflation, 10-Year Rolling Statistics, 1990-2019", 
       y = "Rolling Statistic (Previous 10 Years)", 
       caption = source) +
  pretty_plot()

dev.copy(pdf, "Figures/Growth_Roll_MAD_IQR.pdf", width = 11.27, height = 7)
dev.off()

# Weighted Aggregation for Africa Only: Figure C3
roll_stats %>% 
  fsubset(Year >= 1990 & Area == "Africa" & is.finite(GDP) & is.finite(POP), Year, GDP, POP, 
          GDPCGR_median, INFL_median, GDPCGR_MAD, INFL_MAD) %>% 
  fgroup_by(Year) %>% {
    list(None = slt(., GDPCGR_median:INFL_MAD) %>% fmedian(), 
         GDP = slt(., GDPCGR_median:INFL_MAD, GDP) %>% fmedian(GDP, keep.w = FALSE), 
         POP = slt(., GDPCGR_median:INFL_MAD, POP) %>% fmedian(POP, keep.w = FALSE))
  } %>% unlist2d("Weights", id.factor = TRUE, DT = TRUE) %>% 
  melt(1:2) %>% 
  fmutate(variable = set_attr(variable, "levels", 
                              recode_char(levels(variable),
                                          GDPCGR_median = "Median: GDP per Capita Growth", 
                                          INFL_median = "Median: CPI Inflation", 
                                          GDPCGR_MAD  = "MAD: GDP per Capita Growth", 
                                          INFL_MAD = "MAD: CPI Inflation"))) %>%
  ggplot(aes(x = Year, y = value, colour = Weights)) +
  geom_line() + 
  facet_wrap( ~ variable, scales = "free_y") +
  scale_x_continuous(n.breaks = 6) +
  scale_y_continuous(n.breaks = 10) +
  labs(title = "GDP per Capita Growth and CPI Inflation, 10-Year Rolling Statistics, 1990-2019", 
       y = "Rolling Statistic (Previous 10 Years)", 
       caption = source) +
  pretty_plot()

dev.copy(pdf, "Figures/Growth_Roll_MAD_Weighted.pdf", width = 11.27, height = 7)
dev.off()

# What percent of the trend can be accounted for by time FE: Figure C5
roll_stats_center_summ <- roll_stats %>% 
  fsubset(Year >= 1990, Country, ISO3, Area, Year, 
          GDPCGR_median, INFL_median, GDPCGR_MAD, INFL_MAD) %>% 
  melt(1:4, na.rm = TRUE) %>% 
  fmutate(id = finteraction(ISO3, variable), 
          t = finteraction(Year, variable),
          value_dm = fhdwithin(value, list(id, t)), 
          value_dm_id = fwithin(value, id), 
          value_dm_t = fwithin(value, t), 
          value_dmed = demedian(value, id, t), 
          value_dmed_id = fmedian(value, id, TRA = "-"), 
          value_dmed_t = fmedian(value, t, TRA = "-"), 
          id = NULL, t = NULL) %>% 
  fgroup_by(Area, variable, Year) %>% num_vars() %>%
  fsummarise(N = GRPN(), across(.fns = fmedian))

# Figure C5
roll_stats_center_summ %>% 
   fmutate(variable = set_attr(variable, "levels", 
       recode_char(levels(variable),
              GDPCGR_median = "Median: GDP per Capita Growth", 
              INFL_median = "Median: CPI Inflation", 
              GDPCGR_MAD  = "MAD: GDP per Capita Growth", 
              INFL_MAD = "MAD: CPI Inflation"))) %>%
  ggplot(aes(x = Year, y = value_dmed_t, colour = Area)) +
  geom_line() + 
  facet_wrap( ~ variable, scales = "free_y") +
  scale_colour_manual(values = c("grey20", "orange")) +
  scale_x_continuous(n.breaks = 6) +
  scale_y_continuous(n.breaks = 10) +
  labs(title = "GDP per Capita Growth and CPI Inflation, 10-Year Rolling Statistics, 1990-2019", 
       y = "Rolling Statistic (Previous 10 Years)", 
       caption = source) +
  pretty_plot()

dev.copy(pdf, "Figures/Growth_Roll_MAD_TFE.pdf", width = 11.27, height = 7)
dev.off()


# Rolling Regressions a la Blanchard, O.; Simon, J. (2001). The long and large decline in U.S. output volatility. ----------
DATA[Area %==% "Africa", 
     c(list(Year = Year), 
       qDF(roll::roll_lm(y = GDPCGR, x = L(GDPCGR), width = 15)$coefficients)), # roll v1.1.6
     by = ISO3] %>% na_omit() %>% 
  fsubset(GRPN(ISO3) >= 10L) %>% 
  fgroup_by(Year) %>% num_vars() %>% 
  fsummarise(N = GRPN(), across(.fns = fmedian)) %$% 
  plot(Year, x1, type = "b")

# Growth Recessions according to the IMF (Ahuja et al., (2017); Panth, 2021)
# (i) the 2-year average level of real output per capita post-shock (t and t+1) falls below the pre-shock 3-year average level
# (ii) output per capita growth is negative in the year of the shock (t)
DATA %<>% 
  findex_by(ISO3, Year) %>% 
  ftransform(GREC_dum = GDPCGR < 0 & rowMeans(L(NGDPRPC, 1:3)) > rowMeans(L(NGDPRPC, c(0, -1))),
             GREC_dum_WB = GDPCGR_WB < 0 & rowMeans(L(NY.GDP.PCAP.KD, 1:3)) > rowMeans(L(NY.GDP.PCAP.KD, c(0, -1)))) %>% 
  unindex()

DATA %$% pwcor(GREC_dum, GREC_dum_WB)

# Figure C6: Visualizing growth recessions
DATA[!is.na(Area) & !is.na(GREC_dum), 
     .(.N, REC = sum(GREC_dum, na.rm = TRUE)), 
     keyby = .(Area, Year)][is.finite(REC) & REC > 0] %>%  
  ggplot(aes(x = Year, y = REC, fill = Area)) +
  geom_bar(stat = "identity") + 
  scale_fill_manual(values = c("grey20", "orange")) +
  scale_x_continuous(n.breaks = 10) +
  scale_y_continuous(n.breaks = 10, expand = expansion(mult = c(0, 0.05))) +
  labs(title = "Real GDP per Capita Growth Recessions, 1983-2019", y = "Frequency",
       caption = source) +
  pretty_plot()

dev.copy(pdf, "Figures/PC_Growth_Recession.pdf", width = 8.27, height = 5.3)
dev.off()

# BS-type rolling regressions, aggregated using median/MAD
BS_res <- DATA[Area %==% "Africa", 
     # Manual rolling apply 
     lapply(2005:2019, function(i) {
          ind <- Year < i & Year >= (i-15L)
          x <- GDPCGR[ind]
          rec <- GREC_dum[ind]
          if(sum(complete.cases(x, rec)) < 10L) 
            return(list(Median = NA_real_, AR1 = NA_real_, RSD = NA_real_, RMAD = NA_real_, 
                        AR1_CR = NA_real_, RSD_CR = NA_real_, RMAD_CR = NA_real_))
          mod <- lm(x ~ flag.default(x))
          mod_crisis <- lm(x ~ flag.default(x) + rec)    
          list(Median = fmedian.default(x), # BS use the mean here... 
               AR1 = mod$coefficients[[2L]], 
               RSD = fsd.default(mod$residuals), 
               RMAD = MAD(mod$residuals),
               AR1_CR = mod_crisis$coefficients[[2L]], 
               RSD_CR = fsd.default(mod_crisis$residuals), 
               RMAD_CR = MAD(mod_crisis$residuals))
        }) %>% setNames(2005:2019) %>% 
               rbindlist(idcol = "Year"), 
    by = ISO3][, Year := as.integer(Year)]  

# Figure 2 and C7
BS_res %>% 
  num_vars() %>% 
  fgroup_by(Year) %>% 
  fmedian() %>% 
  melt("Year", variable.factor = FALSE) %>% 
  fmutate(Model = fifelse(endsWith(variable, "_CR"), "Crisis", "Basic"), 
          variable = sub("_CR$", "", variable) %>% 
            recode_char(AR1 = "AR(1)", RSD = "Residual Std. Dev.", RMAD = "Residual MAD") %>% 
            qF(sort = FALSE)) %>%
  ggplot(aes(x = Year, y = value, linetype = Model)) + 
  geom_line() + 
  facet_wrap( ~ variable, scales = "free_y") +
  scale_x_continuous(n.breaks = 8) +
  labs(y = "15-Year Rolling Estimate", caption = source) +
  pretty_plot()

dev.copy(pdf, "Figures/BS_AR1_Analysis.pdf", width = 11.27, height = 5.3)
dev.off()


# Split Sample: 1990-2004 and 2005-2019
summ_stats_split <- DATA %>% 
  fsubset(!is.na(Income) & (is.finite(GDPCGR) | is.finite(INFL)) & Year >= 1990 & Year < 2020, 
          Country, ISO2, ISO3, Region, Income, Area, Year, GDPCGR, INFL) %>% 
  fmutate(Yr05_19 = Year >= 2005) %>%
  fgroup_by(Country:Area, Yr05_19) %>% 
  fsummarise(across(c(GDPCGR, INFL), 
                    list(N = fnobs, median = fmedian, MAD = MAD, IQR = IQR), 
                    na.rm = TRUE, .transpose = TRUE))

# Checking countries with less than 9 observations for either growth or inflation in either period
(ctry <- summ_stats_split %>% fsubset(GDPCGR_N < 9L | INFL_N < 9L, Country, ISO3, Yr05_19, GDPCGR_N, INFL_N))
# Removing these countries
summ_stats_split %<>% fsubset(ISO3 %!in% ctry$ISO3, -GDPCGR_N, -INFL_N)
rm(ctry)

qtab(summ_stats_split$Area)
setdiff(am_countries$ISO3, summ_stats_split$ISO3) # African countries removed

# Summary Stats
qsu(summ_stats_split, ~ Area + Yr05_19, cols = is.numeric)

# Figure C2: Visualizing the Great Moderation for all Countries
summ_stats_split %>% 
  fsubset(Area == "Africa", ISO3, Yr05_19, 
          GDPCGR_median, GDPCGR_MAD, INFL_median, INFL_MAD) %>% 
  melt(1:2, na.rm = TRUE) %>% 
  ftransform(Yr05_19 = c("1990-2004", "2005-2019")[Yr05_19+1L], 
             offset = fifelse(value > fmin(value, list(ISO3, variable), 1L), -0.7, 1.5), 
             variable = set_attr(variable, "levels", recode_char(levels(variable), 
                GDPCGR_median = "GDP/Capita Growth: Median",                                    
                GDPCGR_MAD = "GDP/Capita Growth: MAD",                                  
                INFL_median = "CPI Inflation: Median",                                    
                INFL_MAD = "CPI Inflation: MAD"))) %>% 
  ggplot(aes(x = value, y = ISO3, colour = Yr05_19, shape = Yr05_19)) +
    geom_line(aes(group = ISO3)) +
    geom_point() + 
    geom_text(aes(label = signif(value, 2), hjust = offset), cex = 2, show.legend = FALSE) +
    facet_wrap(~ variable, nrow = 1, scales = "free_x") +
    scale_x_log10(labels = signif, expand = expansion(mult = 0.15)) +
    scale_colour_manual(values = c("red3", "dodgerblue3")) +
    labs(x = "Value (Log10 Scale)", caption = source) +
    pretty_plot(caption.hjust = -0.05) +
    theme(panel.grid.major.x = element_blank(), 
          panel.grid.minor.x = element_blank(), 
          axis.text.y = element_text(size = 7),
          panel.spacing = unit(0.7, "lines"), 
          legend.position = "top", 
          legend.box.spacing = unit(0, "lines"),
          legend.title = element_blank())

dev.copy(pdf, "Figures/GM_All_Countries.pdf", width = 9.5, height = 7.5)
dev.off()


# Table 1
Table_1 <- rbind(
  summ_stats_split[, c(list(N = .N), lapply(num_vars(.SD), median)), by = .(Area, Yr05_19)], 
  summ_stats_split[, c(list(N = .N), lapply(num_vars(.SD), median)), by = .(Area, Income, Yr05_19)], fill = TRUE) %>% 
  colorder(Area, Income, Period = Yr05_19) %>% 
  roworder(Area, Income, na.last = FALSE) %>%
  as_character_factor() %>% 
  ftransform(Area = replace_NA(Income, Area), Income = NULL, 
             Period = c("1990-04", "2005-19")[Period + 1L]) 

print(Table_1)

# Latex export of Table 1
Table_1 %>%
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "") %>% 
  row_spec(c(1:2, 11:12), bold = TRUE) %>% 
  add_indent(c(3:10, 13:20)) %>% 
  collapse_rows(columns = 1, valign = "middle", latex_hline = "none")


# Table C4: Convergence in Volatility: Aggregate with MAD
Table_C4 <- rbind(
  summ_stats_split[, c(list(N = .N), lapply(num_vars(.SD), MAD)), by = .(Area, Yr05_19)], 
  summ_stats_split[, c(list(N = .N), lapply(num_vars(.SD), MAD)), by = .(Area, Income, Yr05_19)], fill = TRUE) %>% 
  colorder(Area, Income, Period = Yr05_19) %>% 
  roworder(Area, Income, na.last = FALSE) %>%
  as_character_factor() %>% 
  ftransform(Area = replace_NA(Income, Area), Income = NULL, 
             Period = c("1990-04", "2005-19")[Period + 1L]) 

print(Table_C4)

# Latex export of Table C4
Table_C4 %>%
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "") %>% 
  row_spec(c(1:2, 11:12), bold = TRUE) %>% 
  add_indent(c(3:10, 13:20)) %>% 
  collapse_rows(columns = 1, valign = "middle", latex_hline = "none")
  

# Empirical Relationship: Split Sample
summ_stats_split_diff <- summ_stats_split %>% 
  fmutate(temp = 1, across(is.numeric, fdiff, g = ISO2, t = Yr05_19)) %>% 
  fsubset(!is.na(temp), -temp)

# Table 2
Table_2 <- rbind(
  summ_stats_split_diff[, as.list(c(N = .N, 
                         rob_beta_r2(GDPCGR_median, GDPCGR_MAD), 
                         rob_beta_r2(INFL_median, INFL_MAD))), by = Area], 
  summ_stats_split_diff[, if(.N > 4) as.list(c(N = .N, 
                                    rob_beta_r2(GDPCGR_median, GDPCGR_MAD), 
                                    rob_beta_r2(INFL_median, INFL_MAD))), by = .(Area, Income)], fill = TRUE) %>% 
  colorder(Area, Income) %>% 
  roworder(Area, Income, na.last = FALSE) %>%
  as_character_factor() %>% 
  add_stub("growth_", cols = 4:6) %>% 
  add_stub("inflation_", cols = 7:9) %>% 
  ftransform(Area = replace_NA(Income, Area), Income = NULL) 

print(Table_2)

# Latex export of Table 2
Table_2 %>%
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "") %>% 
  row_spec(c(1L, 5L), bold = TRUE) %>% 
  add_indent(c(2:4, 6:fnrow(Table_3)))

# Figure C9: RHS
summ_stats_split_diff %>% 
  fsubset(Area == "Africa",
          `Median Growth` = GDPCGR_median, 
          `MAD Growth` = GDPCGR_MAD, 
          `Median Inflation` = INFL_median, 
          `MAD Inflation` = INFL_MAD) %>% 
  replace_outliers(2) %>% 
  chartcorr(method = "robust") 

dev.copy(pdf, "Figures/Growth_Stats_Chartcorr_Diff.pdf", width = 7, height = 5)
dev.off()


# International Synchronization of Business Cycles 

calc_pc1_pve <- function(x) pwcor(x) %>% eigen() %$% proportions(values) %>% extract(1)

calc_pc1_cor_AFR_ROW <- function(d) {
  cm = d %>% qM() %>% pwcor()
  cm_arw = cm[rownames(cm) %in% am_countries$ISO3, rownames(cm) %!in% am_countries$ISO3]
  mean(abs(cm_arw))
}

compute_synchronization <- function(d) {
  lapply(
    list(Overall = d %>% slt(-Year), 
         `1990-2004` = d %>% sbt(Year < 2005, -Year), 
         `2005-2019` = d %>% sbt(Year >= 2005, -Year)),
    function(d_gr) {
      d_gr %<>% gv(fnobs(.) >= 9L & fndistinct(.) >= 3L)
      list(Total = d_gr %>% calc_pc1_pve(),
           Africa = d_gr %>% get_vars(names(.) %in% am_countries$ISO3) %>% calc_pc1_pve(),
           ROW = d_gr %>% get_vars(names(.) %!in% am_countries$ISO3) %>% calc_pc1_pve(), 
           Corr = calc_pc1_cor_AFR_ROW(d_gr))
    }
  ) %>% 
    unlist2d(c("Period", "Region"), DT = TRUE) %>% 
    dcast(Period ~ Region, value.var = "V1")
}  

synch_res <- sapply(c("GDPCGR", "GDPCGR_WB", "INFL", "INFL_WB"), function(i) {
  DATA[Year >= 1990 & Year < 2020, c("ISO3", "Year", i), with = FALSE] %>%
    dcast(Year ~ ISO3, value.var = i) %>% get_vars(fnobs(.) >= 20L) %>% 
    compute_synchronization() %>% colorder(Corr, pos = "end")
}, simplify = FALSE) 

# Table 3
synch_res$GDPCGR %>% add_vars(synch_res$INFL %>% slt(-Period)) %>% 
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "")

# Table C5
synch_res$GDPCGR_WB %>% add_vars(synch_res$INFL_WB %>% slt(-Period)) %>% 
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "")

