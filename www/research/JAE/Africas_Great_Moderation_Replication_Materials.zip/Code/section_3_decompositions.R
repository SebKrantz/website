#########################################
# Africa's Great Moderation
# ---------------------------------------
# Replication Code for Section 3: 
# Decomposing Output Volatility +
# Additional Results in Appendices B & C
# ---------------------------------------
# By Sebastian Krantz (IfW Kiel)
#########################################

# This analysis was conducted using GNU R 4.1.0 for Windows

# Loading Packages
library(collapse)      # v1.8.9
library(data.table)    # v1.14.0
library(kit)           # v0.0.11
library(magrittr)      # v2.0.1
library(africamonitor) # v0.2.1
library(ggplot2)       # v3.3.5
library(kableExtra)    # v1.3.4
# {rrcov} v1.7-4 and {robustbase} v0.93-6 are also used for some computations
# These are quite stable packages, I expect the code to run also with future versions

# Loading Data and Functions
# (Data Series are taken from World Bank and IMF databases and mostly available through the africamonitor API)
DATA_Africa <- readRDS("Data/MACRO_DATA.rds") %>% 
      fsubset(ISO3 %in% am_countries$ISO3)
source("Code/functions.R")

source <- "Data Source: World Development Indicators, Accessed November 2021"

####################################
# Production Side (Appendix C) 
####################################

# Sectoral shares
sec_sh_vars <- .c(NV.AGR.TOTL.ZS, NV.IND.TOTL.ZS, NV.SRV.TOTL.ZS) # GC.TAX.GSRV.VA.ZS

# Getting shares data and adding taxes and deviations category
SEC_Shares <- DATA_Africa %>% 
  get_vars(sec_sh_vars) %>% 
  fmutate(TAX_SD = setLabels(100 - psum(.), "Taxes and Statistical Deviations (% of GDP)")) %>% 
  rm_stub("NV.|.TOTL.ZS", regex = TRUE) %c/% 100

descr(SEC_Shares)

# Generating sectoral GDP data in current and constant USD
SEC_CD <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.MKTP.CD) %>% 
  ftransform(SEC_Shares %c*% NY.GDP.MKTP.CD) %>% 
  rm_stub("NY.|.MKTP.CD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(SEC_CD, vlabels = TRUE)
qtab(SEC_CD$Year)

SEC_KD <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.MKTP.KD) %>% 
  ftransform(SEC_Shares %c*% NY.GDP.MKTP.KD) %>% 
  rm_stub("NY.|.MKTP.KD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(SEC_KD, vlabels = TRUE)
qtab(SEC_KD$Year)

# Generating per-capita data in current and constant USD
SEC_CDPC <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.PCAP.CD) %>% 
  ftransform(SEC_Shares %c*% NY.GDP.PCAP.CD) %>% 
  rm_stub("NY.|.PCAP.CD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(SEC_CDPC, vlabels = TRUE)
qsu(SEC_CDPC, GDP ~ Year)

SEC_KDPC <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.PCAP.KD) %>% 
  ftransform(SEC_Shares %c*% NY.GDP.PCAP.KD) %>% 
  rm_stub("NY.|.PCAP.KD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(SEC_KDPC, vlabels = TRUE)
qsu(SEC_KDPC, GDP ~ Year)

#
### Sector Contribution to GDP -----------------------------------------------------------
#

# Aggregate Average Shares
SEC_Shares_Agg <- SEC_CD %>% 
  fsubset(between(Year, 1990, 2019)) %>%
  fcomputev(AGR:TAX_SD, `/`, GDP, keep = c("Year", "GDP")) %>% 
  fgroup_by(Year) %>% {
    rbindlist(list(Unweighted = fmean(.) %>% fselect(-GDP), 
                  `Weighted by GDP` = fmean(., GDP, keep.w = FALSE)), 
            idcol = "Weights") 
  } 

qsu(SEC_Shares_Agg, ~ Weights)

# Figure C10
SEC_Shares_Agg %>% 
  melt(1:2, na.rm = TRUE) %>%
  ggplot(aes(x = Year, y = value, fill = variable)) +
  geom_area(position = "fill", alpha = 0.8) +
  facet_wrap( ~ Weights) + 
  scale_y_continuous(n.breaks = 10, expand = c(0,0),
                     labels = function(x) scales::percent(x, accuracy = 1)) +
  scale_x_continuous(n.breaks = 10, expand = c(0,0)) +
  guides(fill = guide_legend("Sector")) +
  labs(y = "Mean Across Countries",
       title = "Sectoral Shares in GDP in Africa, 1990-2019", 
       caption = source) +
  pretty_plot() + 
  theme(axis.text.x = element_text(angle = 315, hjust = 0, margin = ggplot2::margin(t = 0)),
        strip.background = element_rect(colour = "white", fill = "white"), 
        panel.spacing.x = unit(1, "lines"))

dev.copy(pdf, "Figures/Decomposition WB/SEC_GDP_Contrib.pdf", width = 8.27, height = 4.5)
dev.off()


#
### Sector Contribution to Real GDP Per Capita Growth -------------------------------------------
#

# Sector Growth Rates
SEC_KDPC_growth <- SEC_KDPC %>% ftransformv(GDP:TAX_SD, fgrowth, g = ISO3, t = Year)

# Sector contribution to aggregate growth
SEC_KDPC_grctrb <- SEC_KDPC %>% 
  ftransform(fselect(., GDP:TAX_SD) %>% fdiff(g = ISO3, t = Year) %/=% flag(GDP) %*=% 100)

descr(SEC_KDPC_grctrb)
# Check
SEC_KDPC_grctrb %>% with(GDP / psum(fselect(., AGR:TAX_SD))) %>% descr()

SEC_KDPC_grctrb_Agg <- SEC_KDPC_grctrb %>% 
  fcomputev(AGR:TAX_SD, `/`, GDP, keep = c("ISO3", "Year")) %>% 
  merge(DATA_Africa %>% fselect(ISO3, Year, POP = SP.POP.TOTL), 
        by = c("ISO3", "Year")) %>% 
  fgroup_by(Year) %>% 
  num_vars() %>% {
    rbindlist(list(Unweighted = fmedian(.) %>% fselect(-POP), 
                   `Weighted by Population` = fmedian(., POP, keep.w = FALSE)), 
              idcol = "Weights") 
  } 

# Figure C11
SEC_KDPC_grctrb_Agg %>% 
  fgroup_by(Weights) %>% 
  fmutate(across(AGR:TAX_SD, frollmean, 10)) %>% 
  fungroup() %>% 
  fsubset(between(Year, 1990, 2019)) %>% 
  melt(1:2, na.rm = TRUE) %>% 
  ggplot(aes(x = Year, y = value, colour = variable)) + 
  geom_line() + 
  facet_wrap( ~ Weights) + 
  scale_y_continuous(n.breaks = 10, labels = function(x) scales::percent(x, accuracy = 1)) +
  scale_x_continuous(n.breaks = 7) +
  guides(colour = guide_legend("Sector")) +
  labs(y = "10-Year MA of Median Country", 
       title = "Sectoral Shares in Average GDP per Capita Growth in Africa",
       caption = source) + 
  pretty_plot() + 
  theme(axis.text.x = element_text(angle = 315, hjust = 0, margin = ggplot2::margin(t = 0)),
        panel.spacing.x = unit(1, "lines"))

dev.copy(pdf, "Figures/Decomposition WB/SEC_GDP_Growth_Contrib.pdf", width = 8.27, height = 4.5)
dev.off()


# Computing GDP without taxes and statistical deviations
SEC_KDPC_shares_noTAX <- SEC_KDPC %>% fcomputev(c(AGR, IND, SRV), `/`, psum(AGR, IND, SRV), keep = .c(ISO3, Year))

SEC_KDPC_growth_noTAX <- SEC_KDPC %>% fselect(-GDP, -TAX_SD) %>% 
                         fmutate(GDP = psum(AGR, IND, SRV), 
                                 across(AGR:GDP, fgrowth, g = ISO3, t = Year))

SEC_KDPC_growth_noTAX %$% frange(Year)
SEC_KDPC_growth_noTAX %$% radixorder(ISO3, Year) %>% attr("sorted")

SEC_KDPC_grctrb_noTAX <- SEC_KDPC %>% fselect(-GDP, -TAX_SD) %>% 
                         fmutate(GDP = psum(AGR, IND, SRV)) %>% 
                         ftransform(fselect(., GDP, AGR, IND, SRV) %>% 
                                    fdiff(g = ISO3, t = Year) %/=% flag(GDP) %*=% 100)

# Check
SEC_KDPC_grctrb_noTAX %>% with(GDP / psum(AGR, IND, SRV)) %>% descr()

# Computing rolling standard deviations
N <- 10
SEC_KDPC_growth_roll10 <- SEC_KDPC_growth_noTAX %>% 
                        add_vars(list(GDP_Level = SEC_KDPC$GDP)) %>% 
                        extract(between(Year, 1981, 2019), c(list(Year = Year, 
                        GDP = frollmean(GDP_Level, N)), 
                        lapply(.SD, frollmean, N) %>% add_stub("_Mean", FALSE),
                        lapply(.SD, frollapply, N, median) %>% add_stub("_Median", FALSE),
                        lapply(.SD, frollapply, N, sd) %>% add_stub("_SD", FALSE), 
                        lapply(.SD, frollapply, N, MAD) %>% add_stub("_MAD", FALSE), 
                        lapply(.SD, frollapply, N, IQR) %>% add_stub("_IQR", FALSE)),
                        by = .(Country, ISO3, Income), .SDcols = .c(GDP, AGR, IND, SRV)) %>% 
                     fsubset(is.finite(GDP_Mean) | is.finite(GDP_Median)) %>% melt(1:5) %>% 
  ftransform(tstrsplit(variable, "_", fixed = TRUE, names = c("Sector", "Statistic"))) %>% 
  ftransformv(c(Sector, Statistic), qF, sort = FALSE)
# Coverage
SEC_KDPC_growth_roll10 %$% fndistinct(Country, Year)

SEC_KDPC_growth_roll10_agg <- SEC_KDPC_growth_roll10 %>% 
  fgroup_by(Year, Sector, Statistic) %>% 
  fsummarise(value = fmedian(value), 
             value_weighted = fmedian(value, w = GDP))


# Figure 3: LHS
SEC_KDPC_growth_roll10_agg[Statistic %in% c("SD", "MAD") & Year >= 2000] %>% 
  ggplot(aes(x = Year, y = value, colour = Sector, linetype = Statistic)) + 
  geom_line() + 
  scale_colour_manual(values = c("black", scales::hue_pal()(4)[1:3])) + 
  labs(y = "Median Across Countries", 
       title = paste0(N, "-Year Rolling Volatility of VAPC Growth"), 
       caption = source) +
  pretty_plot() + 
  theme(plot.title = element_text(hjust = 0.5))

dev.copy(pdf, "Figures/Decomposition WB/SEC_GDP_Growth_RollVar_BySector.pdf", width = 6, height = 6)
dev.off()


# Spectral Decomposition
SEC_KDPC_spec <- 
  SEC_KDPC[between(Year, 1990, 2019)][GRPN(ISO3) > 10] %>% rsplit( ~ ISO3) %>% # sapply(fnrow)
  lapply(with, spec.pgram(log(cbind(GDP, AGR, IND, SRV)), 
                          plot = FALSE, detrend = TRUE, 
                          taper = 0.15, spans = c(3, 7))) %>%
  #lapply(scale_pgram, tovar = TRUE) %>% 
  lapply(with, cbind(frequency = freq, period = 1/freq, setColnames(spec, snames))) %>% 
  unlist2d("ISO3", DT = TRUE)

# Uniform breaks
SEC_KDPC_spec %<>%  
  ftransform(Freq = cut(frequency, breaks = seq(0, 0.5, 1/30)+1e-5))

# Plotting
SEC_KDPC_spec %>% 
  psmat( ~ ISO3, ~ as.integer(Freq), cols = 4:7) %>% log() %>% plot()

# Aggregating
SEC_KDPC_spec %<>%
  fgroup_by(ISO3, Freq) %>% 
  fsummarise(# N = GRPN(),
             Period = fmean(period), 
             across(GDP:SRV, fsum))

# Figure 3: RHS (Aggregate Spectral Density)
SEC_KDPC_spec %>%
  fmutate(Period = fbetween(Period, Freq)) %>%
  fselect(-ISO3, -Freq) %>% 
  fgroup_by(Period) %>% 
  fmedian() %>% 
  melt(1, variable.name = "Sector") %>% 
  
  ggplot(aes(x = Period, y = value, colour = Sector)) + 
  geom_line(aes(group = Sector)) + 
  scale_y_log10(labels = scales::trans_format("log10", scales::math_format(10^.x, format = function(x) round(x, 1)))) + 
  scale_x_log10(n.breaks = 8) +
  annotation_logticks(sides = "lrtb") + 
  scale_colour_manual(values = c("black", scales::hue_pal()(4)[1:3])) + 
  pretty_plot() + 
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), 
        plot.title = element_text(hjust = 0.5)) + 
  labs(x = "Period in Years", y = "Median Spectral Density", 
       title = "Spectral Densities of ln(VAPC)")

dev.copy(pdf, "Figures/Decomposition WB/SEC_logGDP_SpecDec_Period.pdf", width = 6, height = 6)
dev.off()


## Computing the different components of Table C6:
## Sectoral volatility and Contribution to Aggregate Volatility

# Average lagged sectoral shares
SEC_KDPC_shares_noTAX %>% 
  fsubset(between(Year, 1990, 2019)) %>%
  fgroup_by(ISO3) %>% 
  flag(1, Year) %>% 
  fselect(-Year) %>% {
    c(fmean(., keep.g = FALSE) %>% fmean(),
      fmedian(., keep.g = FALSE) %>% fmean())
  } %>% round(3)

# Covariances of sectoral growth rates: Pearsons and Stahel-Donoho Estimator
SEC_KDPC_growth_noTAX[between(Year, 1990, 2019), 
                      na_omit(qM(.SD)) %>% {
                        cbind(cov(.), rrcov::CovSde(., prob = 0.9999, seed = set.seed(21))@cov) # rrcov 1.7-4
                      } %>% qDF("Sector"), 
                      by = .(Country, ISO3, Income), .SDcols = .c(AGR, IND, SRV)] %>%
  fgroup_by(Sector) %>% num_vars() %>% fmedian() %>% 
  kbl("latex", digits = 2)

# Covariances of sectoral growth contributions: Pearsons and Stahel-Donoho Estimator
sec_volctrb <- SEC_KDPC_grctrb_noTAX[between(Year, 1990, 2019), 
                      na_omit(qM(.SD)) %>% {
                        cbind(cov(.), rrcov::CovSde(., prob = 0.9999, seed = set.seed(21))@cov) # rrcov 1.7-4
                      } %>% qDF("Sector"), 
                      by = .(Country, ISO3, Income), .SDcols = .c(AGR, IND, SRV)] %>%
  # ftransformv(is.numeric, `/`, psum(num_vars(.))) %>% 
  fgroup_by(Sector) %>% num_vars() %>% fmedian() 

sec_volctrb %>% kbl("latex", digits = 2)

# Average sector shares in aggregate volatility (mentioned in text)
sec_volctrb %>% get_vars(5:7) %>% qM() %>% divide_by(sum(.)) %T>% 
  print() %>% diag() %>% sum()


# Alternative robust estimator via Minimum Covariance Determinant (MCD) 
SEC_KDPC_growth_noTAX[between(Year, 1990, 2019), 
                      qDF(robustbase::covMcd(.SD, nsamp = 1000)$cov, "Sector"), 
                      by = .(Country, ISO3, Income), .SDcols = .c(AGR, IND, SRV)][,
                     lapply(.SD, median, na.rm = TRUE), by = Sector, .SDcols = .c(AGR, IND, SRV)]

# Alternative robust estimator using Comedian
SEC_KDPC_growth_noTAX[between(Year, 1990, 2019), 
                      qDF(robustbase::covComed(na_omit(.SD))$cov, "Sector"), 
                      by = .(Country, ISO3, Income), .SDcols = .c(AGR, IND, SRV)][,
                     lapply(.SD, median, na.rm = TRUE), by = Sector, .SDcols = .c(AGR, IND, SRV)]




## Now Changes in Growth Volatility ----------

# Checking Biename's identity again
SEC_KDPC_grctrb_noTAX %>% na_omit() %>% 
  extract(j = var(GDP) / sum(cov(cbind(AGR, IND, SRV))), by = .(ISO3, Yr05_19 = Year > 2004))

# Country-level differences

# Can do with different covariance estimators
cov_pearson <- function(x) cov(qM(x))
cov_SDE <- function(x) rrcov::CovSde(x, prob = 0.9999, seed = set.seed(21))@cov # 1.7-4
cov_MCD <- function(x) robustbase::covMcd(x, nsamp = 1000)$cov # 0.93-6
cov_MAD <- function(x) robustbase::covComed(x)$cov # 0.93-6

covfuns <- list(cov_pearson, cov_SDE, cov_MCD, cov_MAD)
names(covfuns) <- c("Pearson", "SDE", "MCD", "Comedian")

# Approach 1: First aggregating, then normalization...
Table4_a <- lapply(covfuns, function(covfun) {
  SEC_KDPC_grctrb_noTAX %>% na_omit() %>% 
    extract(between(Year, 1990, 2019),
            if(.N > 10L) as.list(c(GDP = covfun(GDP), flatten_cov(covfun(cbind(AGR, IND, SRV))))), 
            by = .(ISO3, Yr05_19 = Year > 2004))  %>% 
    D(by = ~ ISO3, t = ~ Yr05_19, stubs = FALSE) %>% na_omit() %>%
    num_vars() %>% {
      rbind(Median = c(N = fnrow(.), fmedian(.)),
            Mean = c(N = fnrow(.), fmean(.)))
    }
})

# For Export
Table4_a %<>% unlist2d("Cov", "Agg") %>%
  fmutate(N = NULL, 
          SUM = psum(AGR, IND, SRV, AGR.IND, AGR.SRV, IND.SRV), 
          Fit = GDP / SUM,
          across(AGR:IND.SRV, `*`, 1/SUM), 
          COV = psum(AGR.IND, AGR.SRV, IND.SRV), 
          SUM = NULL) %>% 
  colorder(Cov, Agg, Fit, GDP, AGR, IND, SRV, COV) %>% 
  fsubset(Cov %!in% c("SDE", "MCD")) %>%
  roworder(Agg)

# Approach 2: Normalizing the equation for individual countries before aggregating
Table4_b <- lapply(covfuns, function(covfun) {
  SEC_KDPC_grctrb_noTAX %>% na_omit() %>% 
  extract(between(Year, 1990, 2019),
          if(.N > 10L) as.list(c(GDP = covfun(GDP), flatten_cov(covfun(cbind(AGR, IND, SRV))))), 
          by = .(ISO3, Yr05_19 = Year > 2004)) %>% 
  D(by = ~ ISO3, t = ~ Yr05_19, stubs = FALSE) %>% na_omit() %>% 
   fmutate(Yr05_19 = NULL,
           SUM = psum(AGR, IND, SRV, AGR.IND, AGR.SRV, IND.SRV), 
           Fit = GDP / SUM, 
           across(AGR:IND.SRV, `*`, 1/SUM), 
           COV = psum(AGR.IND, AGR.SRV, IND.SRV), 
           SUM = NULL) %>% # fsubset(abs(Fit) < 5) %>%
  num_vars() %>% {
    rbind(Median = c(N = fnrow(.), fmedian(.)),
          Mean = c(N = fnrow(.), fmean(.)))
  }
})

# For Export
Table4_b %<>% unlist2d("Cov", "Agg") %>%
  fmutate(N = NULL, 
          SUM = psum(AGR, IND, SRV, AGR.IND, AGR.SRV, IND.SRV), 
          across(AGR:IND.SRV, `*`, 1/SUM), 
          COV = psum(AGR.IND, AGR.SRV, IND.SRV), 
          SUM = NULL) %>% 
  colorder(Cov, Agg, Fit, GDP, AGR, IND, SRV, COV) %>% 
  fsubset(Cov %!in% c("SDE", "MCD")) %>%
  roworder(Agg)

# Table 4
rbind(Table4_a, sbt(Table4_b, Agg == "Median")) %>% 
  rbind(num_vars(.) %>% fmedian() %>%  c(rep(NA, 2), .)) %>% 
  ftransformv(c(Fit, AGR:IND.SRV), function(x) paste0(signif(x, 2)*100, "%")) %>% 
  kbl("latex", digits = 2, booktabs = TRUE, linesep = "")
  

## Now Computing Table 5:
## Structural Change Decomposition of Aggregate Volatility

# First verifying Biename's identity with growth rates
SEC_KDPC_growth_Biename <- SEC_KDPC_growth_noTAX[
  SEC_KDPC_shares_noTAX[, .(ISO3, Year, LS_AGR = shift(AGR), LS_IND = shift(IND), LS_SRV = shift(SRV))
], on = .c(ISO3, Year)] 

SEC_KDPC_growth_Biename %>%
  with(GDP / psum(LS_AGR * AGR, LS_IND * IND, LS_SRV * SRV)) %>% descr()
                        
# Now computing the (approximate) covariance identity

# Can do with different covariance estimators
covfun <- cov_pearson

SEC_KDPC_grcov_RMBI <- SEC_KDPC_growth_Biename[
                        between(Year, 1990, 2019) & is.finite(GDP),
                        if(.N >= 10L) as.list(c(GDP = covfun(GDP), 
                          flatten_cov(covfun(cbind(AGR, IND, SRV))), 
                          fmean(cbind(LS_AGR, LS_IND, LS_SRV)))), 
                        by = .(ISO3, Yr05_19 = Year > 2004)][
                          GRPN(ISO3) == 2L]

# Products of average lagged shares
settransform(SEC_KDPC_grcov_RMBI, 
             LSP_AGR = LS_AGR^2,
             LSP_IND = LS_IND^2,
             LSP_SRV = LS_SRV^2,
             LSP_AGR.IND = LS_AGR * LS_IND, 
             LSP_AGR.SRV = LS_AGR * LS_SRV, 
             LSP_IND.SRV = LS_IND * LS_SRV)

# # Another way to do it: first taking share products and then aggregating,
# # but the above is more consistent with Binename's formula
# SEC_KDPC_grcov_RMBI <- SEC_KDPC_growth_noTAX[SEC_KDPC_shares_noTAX[,
#  .(ISO3, Year, LSP_AGR = AGR^2, LSP_IND = IND^2, LSP_SRV = SRV^2,
#    LSP_AGR.IND = AGR * IND, LSP_AGR.SRV = AGR * SRV, LSP_IND.SRV = IND * SRV)],
#   on = .c(ISO3, Year)][between(Year, 1990, 2019) & is.finite(GDP),
#    if(.N >= 10L) as.list(c(GDP = covfun(GDP),
#    flatten_cov(covfun(cbind(AGR, IND, SRV))),
#    fmean(cbind(LSP_AGR, LSP_IND, LSP_SRV, LSP_AGR.IND, LSP_AGR.SRV, LSP_IND.SRV)[-1L, ]))),
#    by = .(ISO3, Yr05_19 = Year > 2004)][GRPN(ISO3) == 2L]

# Checking the (approximate) identity for the covariance of growth rates
vvc <- .c(AGR, IND, SRV, AGR.IND, AGR.SRV, IND.SRV)
SEC_KDPC_grcov_RMBI %>% 
  with(GDP / psum(gv(., vvc) %c*% gv(., paste0("LSP_", vvc)))) %>% descr()
# -> Broadly correct

## Now Rodrik & McMillan (2011) decomposition:

# First differencing the data between the two periods
SEC_KDPC_grcov_RMBI %<>% 
  findex_by(ISO3, Yr05_19) %>% 
  fmutate(across(c("GDP", vvc, paste0("LSP_", vvc)), D),
          across(paste0("LSP_", vvc), L)) %>%
  unindex()

# This computes the between and within terms of the decomposition (Eq. 5 of the Paper)
SEC_KDPC_grcov_RMBI %<>% 
  ftransform(within = psum(gv(., paste0("L1.LSP_", vvc)) %c*% gv(., paste0("D1.", vvc))), 
             between = psum(gv(., paste0("D1.LSP_", vvc)) %c*% gv(., vvc))) 

# This computes the within and between shares of the aggregate change in growth volatility
RMBI_res <- SEC_KDPC_grcov_RMBI %>% 
  fcompute(within_gdp = within / D1.GDP, 
           between_gdp = between / D1.GDP, 
           fit = (within + between) / D1.GDP, # If the decomposition were exact, this should be 1
           within_sum = within / (within + between),
           between_sum = between / (within + between),
           keep = .c(ISO3, Yr05_19, D1.GDP, within, between)) %>% na_omit() 

# On average we are correct ... but this is even more noisy than Biename's identity with covariances
RMBI_res$fit %T>% hist(breaks = 150) %>% descr()

# See African countries excluded due to data coverage
am_countries %>% fsubset(ISO3 %!in% RMBI_res$ISO3)

# This is reported in Table 5
RMBI_res_agg <- RMBI_res %>% # fsubset(between(fit, 1/3, 3)) %>% 
  num_vars() %>% fmedian(drop = FALSE) %>% {
  rbind(
  None = fcompute(., fit = (within + between) / D1.GDP,
                within_fit = within / (within + between), 
                between_fit = between / (within + between), 
                keep = .c(D1.GDP, within, between)), 
  Shares = fcompute(., D1.GDP = D1.GDP,
                    within = within_gdp, 
                    between = between_gdp,
                    fit = fit, # / (within_gdp + between_gdp),
                    within_fit = within_sum, # / (within_sum + between_sum), 
                    between_fit = between_sum), # / (within_sum + between_sum)), 
  idcol = "Method")
  }

# For Table 5 (top half, repeat with cov_MAD)
RMBI_res_agg %>% 
  ftransformv(endsWith(names(.), "fit"), function(x) paste0(signif(x, 3)*100, "%")) %>% 
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "")


# Also using the Economic Transformation Database (De Vries et al. (2021)) ----------------------

ETD <- readRDS("Data/ETD/etd-release2021.rds") %>%
  fsubset(var == "VA_Q15" & cnt %in% am_countries$ISO3, -wf) %>%
  ftransformv(-(1:4), function(x) as.numeric(gsub(",", "", x))) %>% 
  roworder(cnt, year) %>% qDT()

ETD %$% qtab(country, year) 

ETD_sec <- fselect(ETD, agr:oth, return = "names")

# Plotting Structural Change in the 21 Africa Countries
ETD %>% 
  fselect(-var, -tot) %>% 
  frename(toupper, cols = -(1:3)) %>% 
  melt(1:3) %>% 
  ftransform(value = fifelse(value < 0, 0, value)) %>% 
  ggplot(aes(x = year, y = value, fill = variable)) + 
  geom_area(position = "fill", alpha = 0.9) + 
  facet_wrap( ~ country, ncol = 3) +
  labs(x = NULL, y = NULL) +
  guides(fill = guide_legend("Sector")) +
  theme_linedraw(base_size = 14) + 
  scale_fill_manual(values = sub("#00FF66", "#00CC66", rainbow(12))) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 7), expand = c(0, 0)) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 5), expand = c(0, 0),
                     labels = function(x) scales::percent(x, 1)) +
  theme(axis.text.x = element_text(angle = 315, hjust = 0, margin = ggplot2::margin(t = 0)),
        strip.background = element_rect(colour = "grey20", fill = "grey20"),
        strip.text = element_text(face = "bold"))

dev.copy(pdf, "Figures/Decomposition ETD/SEC_GDP_Shares.pdf", width = 8, height = 11)
dev.off()

# Figure C13: Aggregate Structural Change
ETD %>% 
  fselect(-var) %>% 
  frename(toupper, cols = -(1:3)) %>% 
  num_vars() %>%
  fgroup_by(year) %>% {
    unlist2d(list(Unweighted = fmean(.) %>% fselect(-TOT), 
                  `Weighted by GDP` = fmean(., TOT, keep.w = FALSE)), "weighted", DT = TRUE) 
  } %>%
  melt(1:2) %>% 
  ftransform(value = fifelse(value < 0, 0, value)) %>% 
  ggplot(aes(x = year, y = value, fill = variable)) + 
  geom_area(position = "fill", alpha = 0.9) + 
  facet_wrap( ~ weighted) + 
  labs(x = NULL, y = NULL) +
  guides(fill = guide_legend("Sector")) +
  theme_linedraw(base_size = 14) + 
  scale_fill_manual(values = sub("#00FF66", "#00CC66", rainbow(12))) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 7), expand = c(0, 0)) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 10), expand = c(0, 0),
                     labels = function(x) scales::percent(x, 1)) +
  theme(axis.text.x = element_text(angle = 315, hjust = 0, margin = ggplot2::margin(t = 0)),
        strip.background = element_rect(colour = "grey20", fill = "grey20"),
        strip.text = element_text(face = "bold"))

dev.copy(pdf, "Figures/Decomposition ETD/SEC_GDP_Shares_Agg.pdf", width = 8.27, height = 5)
dev.off()

# Per capita data
ETDPC <- ETD %>% 
  merge(fselect(DATA_Africa, cnt = ISO3, year = Year, pop = SP.POP.TOTL), by = .c(cnt, year)) %>%
  ftransformv(-(1:4), `/`, pop) %>% 
  fselect(-pop)

ETD_shares <- gv(ETD, ETD_sec) %c/% ETD$tot
ETDPC_growth <- ETDPC %>% ftransform(fselect(., agr:tot) %>% fgrowth(g = cnt, t = year)) 
ETDPC_grctrb <- ETDPC %>% ftransform(fselect(., agr:tot) %>% fdiff(g = cnt, t = year) %/=% flag(tot) %*=% 100) 
# Check
ETDPC_grctrb %>% with(tot / psum(gv(., ETD_sec))) %>% descr()
# Verify Bienaymé's identity: 
fvar(ETDPC_grctrb$tot) / sum(pwcov(gv(ETDPC_grctrb, ETD_sec)))



# Sectoral growth volatility
ETDPC_growth %>% 
  fgroup_by(country) %>% 
  num_vars() %>% fsd() %>% 
  num_vars() %>% fmedian() %>% 
  .subset(c(-1, -length(.))) %>% 
  barplot(main = "Sectoral PC Growth Std. Dev.")

# Figure C14: LHS
ETDPC_growth %>% 
  fgroup_by(country) %>% 
  num_vars() %>% BY(IQR, na.rm = TRUE, keep.group_vars = FALSE) %>% 
  fmedian() %>% 
  .subset(c(-1, -length(.))) %>% 
  barplot(main = "Sectoral PC Growth Growth IQR")

dev.copy(pdf, "Figures/Decomposition ETD/SEC_Growth_IQR.pdf", width = 8.27, height = 5.83)
dev.off()

# Checking contribution of sectors to aggregate volatility
ETDPC_grctrb %>% 
  fgroup_by(country) %>% 
  num_vars() %>% fsd() %>% 
  num_vars() %>% fmedian() %>% 
  .subset(c(-1, -length(.))) %>% 
  barplot(main = "Sectoral Contribution to PC Growth Std. Dev.")

# Figure C14: RHS
ETDPC_grctrb %>% 
  fgroup_by(country) %>% 
  num_vars() %>% BY(IQR, na.rm = TRUE, keep.group_vars = FALSE) %>% 
  fmedian() %>% 
  .subset(c(-1, -length(.))) %>% 
  barplot(main = "Sectoral Contribution to PC Growth Growth IQR")

dev.copy(pdf, "Figures/Decomposition ETD/SEC_Grctrb_IQR.pdf", width = 8.27, height = 5.83)
dev.off()


N <- 10 # Size of rolling window

# Rolling Sector Contribution to Real GDP Per Capita Growth (not reported)
ETDPC_grctrb %>% 
  fcomputev(ETD_sec, `/`, tot, keep = "year") %>% 
  fgroup_by(year) %>% num_vars() %>% fmedian() %>%
  ftransformv(-1, frollmean, N) %>%
  melt(1, na.rm = TRUE) %>% 
  ggplot(aes(x = year, y = value, colour = variable)) + 
  geom_line() + 
  scale_y_continuous(n.breaks = 10, labels = function(x) scales::percent(x, accuracy = 1)) +
  scale_x_continuous(n.breaks = 10) +
  guides(colour = guide_legend("Sector")) +
  labs(y = "Share in Real PCGDP Growth: 10-Year MA of Country Medians", 
       title = "Sectoral Shares in Average GDP per Capita Growth in SSA") + 
  pretty_plot()

dev.copy(pdf, "Figures/Decomposition ETD/SEC_GRCTB_Rolling.pdf", width = 8.27, height = 5.83)
dev.off()

# Rolling MAD of sectoral growth rates
ETDPC_growth_roll <- 
  ETDPC_growth[, c(list(Year = year), lapply(.SD, frollapply, N, MAD)), 
               by = .(country, cnt), .SDcols = c("tot", ETD_sec)] %>% na_omit("tot")

# Figure C15: LHS
ETDPC_growth_roll %>% fgroup_by(Year) %>% 
  get_vars(c("tot", ETD_sec)) %>% fmedian() %>% 
  frename(toupper, cols = -1) %>% 
  melt(1, variable.name = "Sector") %>% 
  ggplot(aes(x = Year, y = value, colour = Sector)) + 
  geom_line() + 
  scale_colour_manual(values = c("black", scales::hue_pal()(12))) + 
  scale_y_continuous(n.breaks = 8) +
  labs(y = "Median Across Countries", 
       title = "Rolling MAD of VA per Capita Growth", 
       caption = "Data Source: Economic Transformation Database, February 2021") +
  pretty_plot()

dev.copy(pdf, "Figures/Decomposition ETD/SEC_GDP_Growth_RollMAD_BySector.pdf", width = 6, height = 5)
dev.off()

# Same with Growth Contributions
ETDPC_grctrb_roll <- 
  ETDPC_grctrb[, c(list(Year = year), lapply(.SD, frollapply, N, MAD)), 
               by = .(country, cnt), .SDcols = c("tot", ETD_sec)] %>% na_omit("tot")

# Figure C15: RHS
ETDPC_grctrb_roll %>% fgroup_by(Year) %>% 
  get_vars(ETD_sec) %>% fmedian() %>% 
  frename(toupper, cols = -1) %>% 
  melt(1, variable.name = "Sector") %>% 
  ggplot(aes(x = Year, y = value, colour = Sector)) + 
  geom_line() + 
  scale_y_continuous(n.breaks = 8) +
  labs(y = "Median Across Countries", 
       title = "Rolling MAD of Contributions to Growth", 
       caption = "Data Source: Economic Transformation Database, February 2021") +
  pretty_plot()

dev.copy(pdf, "Figures/Decomposition ETD/SEC_GDP_Grctrb_RollMAD_BySector.pdf", width = 6, height = 5)
dev.off()


# Decomposition: Rodrik & McMillan + Biename's Identity ---------------------
qtab(ETD$year)

# Sectors
v <- ETD_sec

# Biename's identity for growth rates
ETD_KDPC_growth_Biename <- ETDPC_growth %>% 
  ftransform(ETD_shares %>% flag(g = cnt, t = year) %>% add_stub("LS_"))

# Verifying
ETD_KDPC_growth_Biename %>% 
  with(tot / psum(gv(., paste0("LS_", v)) %c*% gv(., v))) %>% descr()

# Combinations of sectors
vc <- combn(v, 2, FUN = paste, collapse = ".")
vcl <- combn(v, 2, FUN = function(x) paste0("LS_", x), simplify = FALSE)
  
# Can do with different covariance estimators
covfun <- cov_pearson

# Computing covariances
ETD_KDPC_grcov_RMBI <- ETD_KDPC_growth_Biename %>%  
  extract(between(year, 1990, 2019) & is.finite(tot), 
    if(.N >= 10) as.list(c(GDP = covfun(tot), 
    flatten_cov(covfun(qM(gv(.SD, v)))), 
    fmean(gv(.SD, paste0("LS_", v))))), 
    by = .(cnt, Yr05_19 = year > 2004)) %>% 
  fsubset(GRPN(cnt) == 2L)

# Computing lag-share products
ETD_KDPC_grcov_RMBI[, paste0("LSP_", v) := lapply(.SD, `^`, 2), .SDcols = paste0("LS_", v)]
ETD_KDPC_grcov_RMBI[, paste0("LSP_", vc) := lapply(vcl, function(x) .subset2(.SD, x[1L]) * .subset2(.SD, x[2L]))]

# Checking the (approximate) identity for the covariance of growth rates
vvc <- c(v, vc)
ETD_KDPC_grcov_RMBI %>% 
  with(GDP / psum(gv(., vvc) %c*% gv(., paste0("LSP_", vvc)))) %>% descr()

## Now Rodrik & McMillan (2011) decomposition:

# First differencing the data between the two periods
ETD_KDPC_grcov_RMBI %<>% 
  findex_by(cnt, Yr05_19) %>% 
  fmutate(across(c("GDP", vvc, paste0("LSP_", vvc)), D),
          across(paste0("LSP_", vvc), L)) %>%
  unindex()

# This computes the between and within terms of the decomposition (Eq. 5 of the Paper)
ETD_KDPC_grcov_RMBI %<>% 
  ftransform(within = psum(gv(., paste0("L1.LSP_", vvc)) %c*% gv(., paste0("D1.", vvc))), 
             between = psum(gv(., paste0("D1.LSP_", vvc)) %c*% gv(., vvc))) 


# This computes the within and between shares of the aggregate change in growth volatility
ETD_RMBI_res <- ETD_KDPC_grcov_RMBI %>% 
  fcompute(within_gdp = within / D1.GDP, 
           between_gdp = between / D1.GDP, 
           fit = (within + between) / D1.GDP, # If the decomposition were exact, this should be 1
           within_sum = within / (within + between),
           between_sum = between / (within + between),
           keep = .c(cnt, Yr05_19, D1.GDP, within, between)) %>% na_omit() 

# On average we are correct ... but this is even more noisy than Biename's identity with covariances
ETD_RMBI_res$fit %T>% hist(breaks = 150) %>% descr()

# This is reported in Table 5
ETD_RMBI_res_agg <- ETD_RMBI_res %>% # fsubset(between(fit, 1/3, 3)) %>% 
  num_vars() %>% fmedian(drop = FALSE) %>% {
    rbind(
      None = fcompute(., fit = (within + between) / D1.GDP,
                     within_fit = within / (within + between), 
                     between_fit = between / (within + between), 
                     keep = .c(D1.GDP, within, between)), 
      Shares = fcompute(., D1.GDP = D1.GDP,
                        within = within_gdp, 
                        between = between_gdp,
                        fit = fit, # / (within_gdp + between_gdp),
                        within_fit = within_sum, # / (within_sum + between_sum), 
                        between_fit = between_sum), # / (within_sum + between_sum)), 
      idcol = "Method")
  }

# For Table 5 (bottom half, repeat with cov_MAD)
ETD_RMBI_res_agg %>% 
  ftransformv(endsWith(names(.), "fit"), function(x) paste0(signif(x, 3)*100, "%")) %>% 
  kbl("latex", digits = 3, booktabs = TRUE, linesep = "")




# Country Classification (Appendix Tables C7 and C8) --------------------------------------

# Between County-Sectors
SEC_KDPC_noTAX_MADs <- SEC_KDPC_grctrb_noTAX %>% 
  fselect(-Year) %>% collap( ~ ISO3, MAD, ffirst, na.rm = TRUE) %>% 
  melt(1:3, variable.name = "Source", value.name = "MAD_Grctrb") %>% 
  merge(SEC_KDPC_growth_noTAX %>% fgroup_by(ISO3) %>% fselect(AGR:GDP) %>% BY(MAD, na.rm = TRUE) %>%
          melt("ISO3", variable.name = "Source", value.name = "MAD_Growth"), by = .c(ISO3, Source)) %>% 
  colorder(Country, ISO3)

INSTA_Class_Grctrb <- SEC_KDPC_noTAX_MADs[Source %in% c("AGR", "IND", "SRV"), ss(.SD, which.max(MAD_Grctrb)), by = ISO3]
INSTA_Class_Growth <- SEC_KDPC_noTAX_MADs[Source %in% c("AGR", "IND", "SRV"), ss(.SD, which.max(MAD_Growth)), by = ISO3]
INSTA_Class_Comb <- fselect(INSTA_Class_Grctrb, Country, ISO3, MAD_Grctrb = Source) %>% 
               merge(fselect(INSTA_Class_Growth, ISO3, MAD_Growth = Source), by = "ISO3") 

# Table C7: Top Half
INSTA_Class_Grctrb %$% split(ISO3, Source) %>% lapply(paste, collapse = ", ")
INSTA_Class_Grctrb %$% split(Country, Source) %>% lengths()

# Table C7: Bottom Half
INSTA_Class_Growth %$% split(ISO3, Source) %>% lapply(paste, collapse = ", ")
INSTA_Class_Growth %$% split(ISO3, Source) %>% lengths()

# Table C7: Difference
INSTA_Class_Comb[MAD_Grctrb != MAD_Growth] %$% split(ISO3, MAD_Growth) %>% lapply(paste, collapse = ", ") # Added
INSTA_Class_Comb[MAD_Grctrb != MAD_Growth] %$% split(ISO3, MAD_Grctrb) %>% lapply(paste, collapse = ", ") # Removed

INSTA_Class_Comb[MAD_Grctrb != MAD_Growth] %$% split(Country, MAD_Growth)
INSTA_Class_Comb[MAD_Grctrb != MAD_Growth & MAD_Grctrb == "IND"] 


# Aggregate Sectoral Growth Stabilization

SEC_KDPC_noTAX_MAD_Diff <- SEC_KDPC_grctrb_noTAX %>% 
  ftransform(Yr05_19 = Year > 2004) %>% fselect(-Year) %>% 
  collap( ~ ISO3 + Yr05_19, list(fmedian, MAD), ffirst, na.rm = TRUE, return = "long_dupl") %>% 
  melt(.c(Function, Country, ISO3, Income, Yr05_19), variable.name = "Source", value.name = "MAD_Grctrb") %>% 
  merge(SEC_KDPC_growth_noTAX %>% ftransform(Yr05_19 = Year > 2004) %>% fselect(-Year) %>% 
          collap( ~ ISO3 + Yr05_19, list(fmedian, MAD), ffirst, na.rm = TRUE, return = "long_dupl") %>% 
          fselect(-Country, -Income) %>% 
          melt(.c(Function, ISO3, Yr05_19), variable.name = "Source", value.name = "MAD_Growth"), 
        by = .c(Function, ISO3, Yr05_19, Source))
  


SEC_KDPC_noTAX_MAD_Diff <- SEC_KDPC_noTAX_MAD_Diff %>% fsubset(Function == "MAD", -Function)

SEC_KDPC_noTAX_MAD_Diff %<>% 
  ftransform(fmedian(list(MAD_Grctrb_Med = MAD_Grctrb, 
                          MAD_Growth_Med = MAD_Growth), Source, TRA = "replace_fill")) %>%
  ftransform(Grctrb_Above = MAD_Grctrb > MAD_Grctrb_Med, 
             Growth_Above = MAD_Grctrb > MAD_Grctrb_Med)

# Table C8: Top half
SEC_KDPC_noTAX_MAD_Diff %>% 
  fgroup_by(Yr05_19, Source) %>% 
  fselect(MAD_Grctrb, MAD_Growth) %>% 
  fmedian() %>% 
  list(SEC_KDPC_noTAX_MAD_Diff %>% 
       fgroup_by(Source) %>% 
       fselect(MAD_Grctrb_Med, MAD_Growth_Med) %>% 
       fmedian() %>% rm_stub("_Med", FALSE)) %>% 
  rbindlist(fill = TRUE) %>% 
  fsubset(Source != "GDP") %>% 
  melt(1:2) %>% 
  dcast(variable ~ Yr05_19 + Source) %>% 
  kbl("latex", digits = 2, booktabs = TRUE)

# Table C8: Bottom half
tmp <- collap(SEC_KDPC_noTAX_MAD_Diff, ~ISO3 + Source)
Nc <- fndistinct(tmp$ISO3)
rbind(
  MAD_Grctrb = tmp[Source %!in% "GDP" & MAD_Grctrb > MAD_Grctrb_Med, qtab(Source)/Nc],
  MAD_Growth = tmp[Source %!in% "GDP" & MAD_Growth > MAD_Growth_Med, qtab(Source)/Nc]  
) %>% qDT("Metric") %>% 
rbind(list(
  MAD_Grctrb = SEC_KDPC_noTAX_MAD_Diff[Source %!in% "GDP" & MAD_Grctrb > MAD_Grctrb_Med, qtab(Yr05_19, Source)/Nc], 
  MAD_Growth = SEC_KDPC_noTAX_MAD_Diff[Source %!in% "GDP" & MAD_Growth > MAD_Growth_Med, qtab(Yr05_19, Source)/Nc]
) %>% unlist2d("Metric", "Time", DT = TRUE), fill = TRUE) %>% 
 fselect(-GDP) %>% 
 dcast(Metric ~ Time, value.var = .c(AGR, IND, SRV)) %>% 
 colorderv(c("Metric", "NA", "FALSE", "TRUE"), regex = TRUE) %>% 
 kbl("latex", digits = 2, booktabs = TRUE)
rm(tmp)

SEC_KDPC_noTAX_MAD_Diff[Source %!in% "GDP" & Growth_Above & !Yr05_19] %$% split(ISO3, Source) %>% lengths()
SEC_KDPC_noTAX_MAD_Diff[Source %!in% "GDP" & Growth_Above & Yr05_19] %$% split(ISO3, Source) %>% lengths()

# Figure C16
SEC_KDPC_noTAX_MAD_Diff[Source %!in% "GDP"] %>% 
  dcast(ISO3 + Yr05_19 ~ Source, value.var = "MAD_Grctrb") %>% 
  ftransform(Yr05_19 = fifelse(Yr05_19, "2005-2019", "1990-2004          ")) %>% 
  melt(1:2) %>%
  ftransform(offset = fifelse(value > fmin(value, list(ISO3, variable), 1L), -0.7, 1.5), 
      ISO3 = factor(ISO3, levels = sort(unique(ISO3), decreasing = TRUE))) %>% 
  ggplot(aes(x = value, y = ISO3, colour = Yr05_19, shape = Yr05_19)) + 
  geom_line(aes(group = ISO3)) +
  geom_point() + 
  geom_text(aes(label = signif(value, 2), hjust = offset), cex = 2, show.legend = FALSE) +
  facet_wrap(~ variable) +
  scale_x_log10(labels = signif, expand = c(0, 0.25)) +
  scale_colour_manual(values = c("red3", "dodgerblue3")) +
  labs(x = bquote("Sectoral Volatility Contribution: " ~ MAD(Delta*y[t]/Y[t-1])), 
       caption = source) +
  pretty_plot() +
  theme(panel.grid.major.x = element_blank(), 
        panel.grid.minor.x = element_blank(), 
        axis.text.y = element_text(size = 7),
        panel.spacing = unit(0.7, "lines"), 
        legend.position = "top", 
        legend.box.spacing = unit(0, "lines"),
        legend.title = element_blank())

dev.copy(pdf, "Figures/Decomposition WB/SEC_Vol_Contrib_Countries.pdf", width = 8.27, height = 6.83)
dev.off()


# Regional Overview
SEC_KDPC_noTAX_MAD_Diff %<>% merge(qDT(slt(am_countries, ISO3, Region_Detailed)), by = "ISO3")

# Table C9
SEC_KDPC_noTAX_MAD_Diff %>% fselect(ISO3, Region_Detailed) %>% funique() %>% 
  rsplit(ISO3 ~ Region_Detailed) %>% lapply(paste, collapse = ", ")

SEC_KDPC_noTAX_MAD_Diff_Region_Detailed <- 
  SEC_KDPC_noTAX_MAD_Diff %>% 
  fgroup_by(Region_Detailed, Source, Yr05_19) %>% 
  fselect(MAD_Grctrb, MAD_Growth) %>% 
  fsummarise(across(.fns = fmedian), N = GRPN())

# Table C10
SEC_KDPC_noTAX_MAD_Diff_Region_Detailed %>% 
  fsubset(Source != "GDP") %>% 
  dcast(Region_Detailed + Yr05_19 + N ~ Source, 
        value.var = .c(MAD_Grctrb, MAD_Growth)) %>% 
  ftransform(Yr05_19 = fifelse(Yr05_19, "2005-2019", "1990-2004"), 
             Region_Detailed = sub(" Africa", "", Region_Detailed)) %>%
  kbl("latex", digits = 2, booktabs = TRUE, linesep = "")

# Figure C17
SEC_KDPC_noTAX_MAD_Diff_Region_Detailed %>% 
  fmutate(Yr05_19 = fifelse(Yr05_19, "2005-2019", "1990-2004"), N = NULL) %>% 
  melt(1:3) %>% 
  frename(Yr05_19 = Period) %>% 
  ggplot(aes(x = Region_Detailed, y = value, fill = Period)) + 
  geom_bar(stat = "identity", alpha = 0.8, position = position_dodge(0.9)) +
  facet_grid(variable ~ Source, scales = "free_y") +
  scale_fill_brewer(palette = "Paired") +
  labs(y = "Value", x = "Region", caption = source) +
  pretty_plot() + 
  theme(axis.text.x = element_text(angle = 315, hjust = 0, margin = ggplot2::margin(t = 0)))

dev.copy(pdf, "Figures/Decomposition WB/SEC_Growth_Vol_Regions.pdf", width = 8.27, height = 5.83)
dev.off()


# All countries: Table D1 (separate online Appendix D)
SEC_KDPC_noTAX_MAD_Diff[Source %!in% "GDP"] %>% 
  dcast(ISO3 + Yr05_19 ~ Source, value.var = .c(MAD_Grctrb, MAD_Growth)) %>% 
  ftransform(Yr05_19 = fifelse(Yr05_19, "2005-2019", "1990-2004")) %>% 
  fsubset(GRPN(ISO3) == 2L) %>% 
  kbl("latex", digits = 2, booktabs = TRUE, linesep = "")

# Largest Drop in Sectoral growth volatility
SEC_KDPC_noTAX_MAD_Diff[, MAD_Growth_Diff := fdiff(MAD_Growth, g = list(ISO3, Source), t = Yr05_19)]
SEC_KDPC_noTAX_MAD_Diff[order(MAD_Growth_Diff)] # %>% View()




####################################
# Expenditure Side (Appendix B)
####################################

# Sectoral shares
exp_sh_vars <- .c(NE.CON.GOVT.ZS, NE.CON.PRVT.ZS, NE.GDI.FTOT.ZS, NE.GDI.TOTL.ZS, NE.EXP.GNFS.ZS, NE.IMP.GNFS.ZS)

# Aggregate Expenditure Shares
EXP_Shares <- DATA_Africa %>% get_vars(exp_sh_vars) %c/% 100 %>% 
  fcompute(C = NE.CON.PRVT.ZS, 
           I = NE.GDI.TOTL.ZS, 
           G = NE.CON.GOVT.ZS, 
           NX = NE.EXP.GNFS.ZS - NE.IMP.GNFS.ZS) %>% 
  fmutate(SD = 1 - psum(.))

qsu(EXP_Shares, vlabels = TRUE)

# Disaggregated Exenditure Shares
EXP_Shares_DA <- DATA_Africa %>% get_vars(exp_sh_vars) %c/% 100 %>% 
  fcompute(C = NE.CON.PRVT.ZS, 
           I = NE.GDI.FTOT.ZS, 
           CINV = NE.GDI.TOTL.ZS - NE.GDI.FTOT.ZS, 
           G = NE.CON.GOVT.ZS, 
           X = NE.EXP.GNFS.ZS, 
           M = -NE.IMP.GNFS.ZS) %>% 
  fmutate(SD = 1 - psum(.))

qsu(EXP_Shares_DA, vlabels = TRUE)


# Generating sectoral GDP data in current and constant USD
EXP_CD <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.MKTP.CD) %>% 
  ftransform(EXP_Shares %c*% NY.GDP.MKTP.CD) %>% 
  rm_stub("NY.|.MKTP.CD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(EXP_CD, vlabels = TRUE)
qtab(EXP_CD$Year)

EXP_KD <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.MKTP.KD) %>% 
  ftransform(EXP_Shares %c*% NY.GDP.MKTP.KD) %>% 
  rm_stub("NY.|.MKTP.KD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(EXP_KD, vlabels = TRUE)
qtab(EXP_KD$Year)

# Generating per-capita data in current and constant USD
EXP_CDPC <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.PCAP.CD) %>% 
  ftransform(EXP_Shares %c*% NY.GDP.PCAP.CD) %>% 
  rm_stub("NY.|.PCAP.CD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(EXP_CDPC, vlabels = TRUE)
qsu(EXP_CDPC, GDP ~ Year)

EXP_KDPC <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.PCAP.KD) %>% 
  ftransform(EXP_Shares %c*% NY.GDP.PCAP.KD) %>% 
  rm_stub("NY.|.PCAP.KD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(EXP_KDPC, vlabels = TRUE)
qsu(EXP_KDPC, GDP ~ Year)

## Same using more detailed disaggregation

# Generating sectoral GDP data in current and constant USD
EXP_CD_DA <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.MKTP.CD) %>% 
  ftransform(EXP_Shares_DA %c*% NY.GDP.MKTP.CD) %>% 
  rm_stub("NY.|.MKTP.CD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(EXP_CD_DA, vlabels = TRUE)
qtab(EXP_CD_DA$Year)

EXP_KD_DA <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.MKTP.KD) %>% 
  ftransform(EXP_Shares_DA %c*% NY.GDP.MKTP.KD) %>% 
  rm_stub("NY.|.MKTP.KD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(EXP_KD_DA, vlabels = TRUE)
qtab(EXP_KD_DA$Year)

# Generating per-capita data in current and constant USD
EXP_CDPC_DA <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.PCAP.CD) %>% 
  ftransform(EXP_Shares_DA %c*% NY.GDP.PCAP.CD) %>% 
  rm_stub("NY.|.PCAP.CD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(EXP_CDPC_DA, vlabels = TRUE)
qsu(EXP_CDPC_DA, GDP ~ Year)

EXP_KDPC_DA <- DATA_Africa %>% 
  fselect(Country, ISO3, Income, Year, NY.GDP.PCAP.KD) %>% 
  ftransform(EXP_Shares_DA %c*% NY.GDP.PCAP.KD) %>% 
  rm_stub("NY.|.PCAP.KD|NV.|.TOTL.CD", regex = TRUE) %>% 
  na_omit()

qsu(EXP_KDPC_DA, vlabels = TRUE)
qsu(EXP_KDPC_DA, GDP ~ Year)

# Figure B1: GDP Shares: Expenditure Side
EXP_CD_DA %>% 
  fsubset(between(Year, 1990, 2019)) %>% 
  ftransform(NX = X + M, M = -M) %>% 
  fcomputev(C:NX, `/`, GDP, keep = c("Year", "GDP")) %>% # slt(-Year) %>% psum %>% qsu
  fgroup_by(Year) %>% num_vars() %>% {
    unlist2d(list(Unweighted = fmean(.) %>% fselect(-GDP), 
                  `Weighted by GDP` = fmean(., GDP, keep.w = FALSE)), "weighted", DT = TRUE) 
  } %>% 
  melt(1:2, na.rm = TRUE) %>%
  ggplot(aes(x = Year, y = value, colour = variable)) +
  geom_line() +
  facet_wrap( ~ weighted) + 
  scale_y_continuous(n.breaks = 10, 
                     labels = function(x) scales::percent(x, accuracy = 1)) +
  scale_x_continuous(n.breaks = 10) +
  guides(colour = guide_legend("Expenditure")) +
  labs(y = "Mean Across Countries",
       title = "Expenditure Shares in GDP in Africa", 
       caption = source) +
  pretty_plot() + 
  theme(axis.text.x = element_text(angle = 315, hjust = 0, margin = ggplot2::margin(t = 0)),
        panel.spacing.x = unit(1, "lines"))

dev.copy(pdf, "Figures/Decomposition WB/EXP_GDP_Contrib.pdf", width = 8.27, height = 4.5)
dev.off()

# Figure B2: Sector Contribution to Real GDP Per Capita Growth

EXP_KDPC_grctrb <- EXP_KDPC %>% ftransform(gv(., -(1:4)) %>% fdiff(g = ISO3, t = Year) %c/% (flag(GDP) / 100))  
# Check
EXP_KDPC_grctrb %>% with(GDP / psum(gv(., -(1:5)))) %>% descr
qsu(EXP_KDPC_grctrb)

# Figure B2
EXP_KDPC_grctrb %>% 
  fsubset(between(Year, 1981, 2019)) %>% 
  fcomputev(C:SD, `/`, GDP, keep = c("ISO3", "Year")) %>% 
  merge(DATA_Africa %>% fselect(ISO3, Year, POP = SP.POP.TOTL), by = .c(ISO3, Year)) %>% 
  fgroup_by(Year) %>% num_vars() %>% {
    unlist2d(list(Unweighted = fmedian(.) %>% fselect(-POP), 
                  `Weighted by Population` = fmedian(., POP, keep.w = FALSE)), "weighted", DT = TRUE) 
  } %>% 
  fgroup_by(weighted) %>% 
  fmutate(across(C:SD, frollmean, 10)) %>%
  fungroup() %>% 
  melt(1:2, na.rm = TRUE) %>% 
  tfm(Year = as.integer(Year)) %>% 
  ggplot(aes(x = Year, y = value, colour = variable)) + 
  geom_line() + 
  facet_wrap( ~ weighted) + 
  scale_y_continuous(n.breaks = 10, labels = function(x) scales::percent(x, accuracy = 1)) +
  scale_x_continuous(n.breaks = 7) +
  guides(colour = guide_legend("Expenditure")) +
  labs(y = "10-Year MA of Median Country", 
       title = "Expenditure Shares in Average GDP per Capita Growth in Africa",
       caption = source) + 
  pretty_plot() + 
  theme(axis.text.x = element_text(angle = 315, hjust = 0, margin = ggplot2::margin(t = 0)),
        panel.spacing.x = unit(1, "lines"))

dev.copy(pdf, "Figures/Decomposition WB/EXP_GDP_Growth_Contrib.pdf", width = 8.27, height = 4.5)
dev.off()


# Computing growth rates
EXP_KDPC_growth <- EXP_KDPC_DA %>% 
  ftransform(NX = X + M, M = -M, I = I + CINV, CINV = NULL) %>% 
  ftransformv(-(1:4), fgrowth, g = ISO3, t = Year)

qsu(EXP_KDPC_growth)

# Computing rolling statistica, analogous to production side
N <- 10
EXP_KDPC_growth_roll10 <- EXP_KDPC_growth %>% 
  add_vars(list(GDP_Level = EXP_KDPC_DA$GDP)) %>% 
  extract(between(Year, 1981, 2019), c(list(Year = Year, 
                                            GDP = frollmean(GDP_Level, N)), 
                                       lapply(.SD, frollmean, N) %>% add_stub("_Mean", FALSE),
                                       lapply(.SD, frollapply, N, median) %>% add_stub("_Median", FALSE),
                                       lapply(.SD, frollapply, N, sd) %>% add_stub("_SD", FALSE), 
                                       lapply(.SD, frollapply, N, MAD) %>% add_stub("_MAD", FALSE), 
                                       lapply(.SD, frollapply, N, IQR) %>% add_stub("_IQR", FALSE)),
          by = .(Country, ISO3, Income), .SDcols = .c(GDP, C, I, G, X, M)) %>% 
  fsubset(is.finite(GDP_Mean) | is.finite(GDP_Median)) %>% melt(1:5) %>% 
  ftransform(tstrsplit(variable, "_", fixed = TRUE, names = c("Sector", "Statistic"))) %>% 
  ftransformv(c(Sector, Statistic), qF, sort = FALSE)
# Coverage
EXP_KDPC_growth_roll10 %$% fndistinct(Country, Year)

EXP_KDPC_growth_roll10_agg <- EXP_KDPC_growth_roll10 %>% 
  fgroup_by(Year, Sector, Statistic) %>% 
  fsummarise(value = fmedian(value), 
             value_weighted = fmedian(value, w = GDP))


# Figure B3: LHS: Plot Changes in Volatility over time in one chart
EXP_KDPC_growth_roll10_agg[Statistic %in% c("SD", "MAD") & Year >= 2000] %>% 
  ggplot(aes(x = Year, y = value, colour = Sector, linetype = Statistic)) + 
  geom_line() + 
  scale_colour_manual(values = c("black", scales::hue_pal()(5)[1:5])) + 
  labs(y = "Median Across Countries", 
       title = paste0(N, "-Year Rolling Volatility of EXPPC Growth"), 
       caption = source) +
  pretty_plot() + 
  theme(plot.title = element_text(hjust = 0.5))

dev.copy(pdf, "Figures/Decomposition WB/EXP_GDP_Growth_RollVar_BySector.pdf", width = 6, height = 6)
dev.off()


# Spectral Decomposition
EXP_KDPC_DA_spec <- 
  EXP_KDPC_DA[between(Year, 1990, 2019)][GRPN(ISO3) > 10] %>% 
  tfm(I = I + CINV, CINV = NULL) %>% 
  rsplit( ~ ISO3) %>% 
  lapply(with, spec.pgram(log(cbind(GDP, C, I = I - min(I) + 1, G, X, M = -M)), 
                          plot = FALSE, detrend = TRUE, 
                          taper = 0.15, spans = c(3, 7))) %>%
  #lapply(scale_pgram, tovar = TRUE) %>% 
  lapply(with, cbind(frequency = freq, period = 1/freq, setColnames(spec, snames))) %>% 
  unlist2d("ISO3", DT = TRUE)

EXP_KDPC_DA_spec %<>%  
  ftransform(Freq = cut(frequency, breaks = seq(0, 0.5, 1/30)+1e-5)) %>%
  fgroup_by(ISO3, Freq) %>% 
  fsummarise(# N = GRPN(),
    Period = fmean(period), 
    across(GDP:M, fsum))

# Figure B3: RHS: Aggregate Spectral Density
EXP_KDPC_DA_spec %>%
  fmutate(Period = fbetween(Period, Freq)) %>%
  fselect(-ISO3, -Freq) %>% 
  fgroup_by(Period) %>% 
  fmedian() %>% 
  melt(1, variable.name = "Sector") %>% 
  
  ggplot(aes(x = Period, y = value, colour = Sector)) + 
  geom_line(aes(group = Sector)) + 
  scale_y_log10(labels = scales::trans_format("log10", scales::math_format(10^.x, format = function(x) round(x, 1)))) + 
  scale_x_log10(n.breaks = 8) +
  annotation_logticks(sides = "lrtb") + 
  scale_colour_manual(values = c("black", scales::hue_pal()(5)[1:5])) + 
  pretty_plot() + 
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), 
        plot.title = element_text(hjust = 0.5)) + 
  labs(x = "Period in Years", y = "Median Spectral Density", 
       title = "Spectral Densities of ln(EXPPC)")

dev.copy(pdf, "Figures/Decomposition WB/EXP_logGDP_SpecDec_Period.pdf", width = 6, height = 6)
dev.off()


## Computing the different components of Table B1:
## Sectoral volatility and Contribution to Aggregate Volatility

EXP_KDPC_shares <- EXP_KDPC_DA %>% 
  tfm(GDP = C + I + CINV + G + X + M, I = I + CINV) %>% 
  tfmv(-(1:4), `/`, GDP) %>% 
  tfm(CINV = NULL, SD = NULL)

# Average lagged sectoral shares
EXP_KDPC_shares %>% 
  fsubset(between(Year, 1990, 2019)) %>% 
  fgroup_by(ISO3) %>% num_vars() %>%
  flag(1, Year) %>% 
  fselect(-Year, -GDP) %>% {
    c(fmean(., keep.g = FALSE) %>% fmean(),
      fmedian(., keep.g = FALSE) %>% fmean())
  } %>% round(3)


# Covariances of sectoral growth rates: Pearsons and Stahel-Donoho Estimator
EXP_KDPC_growth %>% tfm(M = -M) %>% 
  extract(between(Year, 1990, 2019) & GRPN(ISO3) > 10L, 
      na_omit(qM(.SD)) %>% {
        cbind(cov(.), rrcov::CovSde(., prob = 0.9999, seed = set.seed(21))@cov) # rrcov 1.7-4
      } %>% qDF("Sector"), 
      by = .(Country, ISO3, Income), .SDcols = .c(C, I, G, X, M)) %>%
  fgroup_by(Sector, sort = FALSE) %>% num_vars() %>% fmedian() %>% 
  kbl("latex", digits = 2)

# Verify Biename's Identity
EXP_KDPC_grctrb_DA %>% 
  with(fvar(GDP) / sum(pwcov(cbind(C, I, G, X, M))))

# Covariances of sectoral growth contributions: Pearsons and Stahel-Donoho Estimator
sec_volctrb <- EXP_KDPC_grctrb_DA[between(Year, 1990, 2019) & GRPN(ISO3) > 10L, 
     na_omit(qM(.SD)) %>% {
       cbind(cov(.), rrcov::CovSde(., prob = 0.9999, seed = set.seed(21))@cov) # rrcov 1.7-4
     } %>% qDF("Sector"), 
     by = .(Country, ISO3, Income), .SDcols = .c(C, I, G, X, M)] %>%
  fgroup_by(Sector, sort = FALSE) %>% num_vars() %>% fmedian() 

sec_volctrb %>% kbl("latex", digits = 2)

# Average sector shares in aggregate volatility (mentioned in text)
sec_volctrb %>% get_vars(7:11) %>% qM() %>% divide_by(sum(.)) %T>% 
  print() %>% diag() %>% sum()


# Now evaluation GM contribution
# With Expenditure only the second approach is sensible 
covfuns <- list(cov_pearson, cov_MAD)
names(covfuns) <- c("Pearson", "Comedian")

# Table B2: Normalizing the equation for individual countries before aggregating
Table_B2 <- lapply(covfuns, function(covfun) {
  EXP_KDPC_grctrb_DA %>% na_omit() %>% 
    extract(between(Year, 1990, 2019),
            if(.N > 10L) as.list(c(GDP = covfun(GDP), flatten_cov(covfun(cbind(C, I, G, X, M))))), 
            by = .(ISO3, Yr05_19 = Year > 2004)) %>% 
    D(by = ~ ISO3, t = ~ Yr05_19, stubs = FALSE) %>% na_omit() %>% 
    fmutate(Yr05_19 = NULL, 
            SUM = psum(slt(., C:X.M)), 
            Fit = GDP / SUM,
            across(C:X.M, `*`, 1/SUM), 
            COV = psum(slt(., C.I:X.M)), 
            SUM = NULL) %>% # fsubset(abs(Fit) < 5) %>%
    num_vars() %>% {
      rbind(Median = c(N = fnrow(.), fmedian(.)),
            Mean = c(N = fnrow(.), fmean(.)))
    }
})

# For Export
Table_B2 %<>% unlist2d("Cov", "Agg") %>%
  fmutate(N = NULL, 
          SUM = psum(slt(., C:X.M)), 
          across(C:X.M, `*`, 1/SUM), 
          COV = psum(slt(., C.I:X.M)), 
          SUM = NULL)  %>% 
  fselect(Cov, Agg, Fit, GDP, C, I, G, X, M, COV) %>% 
  roworder(Agg)


# Table B2
Table_B2 %>% # slt(C:COV) %>% psum() # Check
  fsubset(Agg == "Median") %>% # Only median Agg reported, as in Table 4
  ftransformv(c(Fit, C:COV), function(x) paste0(signif(x, 2)*100, "%")) %>% 
  kbl("latex", digits = 2, booktabs = TRUE, linesep = "")
