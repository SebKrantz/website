#########################################
# Africa's Great Moderation
# ---------------------------------------
# Replication Code for Appendix A:
# Spectral Analysis
# ---------------------------------------
# By Sebastian Krantz (IfW Kiel)
#########################################

# This analysis was conducted using GNU R 4.1.0 for Windows

# Loading Packages
library(collapse)      # v1.8.9
library(data.table)    # v1.14.0
library(magrittr)      # v2.0.1
library(africamonitor) # v0.2.1
library(ggplot2)       # v3.3.5
library(robustbase)    # 0.93-6
# {rrcov} v1.7-4 and {robustbase} v0.93-6 are also used for some computations
# These are quite stable packages, I expect the code to run also with future versions

# Loading Data and Functions
# (Data Series are taken from World Bank and IMF databases and mostly available through the africamonitor API)
DATA <- readRDS("Data/MACRO_DATA.rds")
source("Code/functions.R")

# Describing the data
DATA_labels <- namlab(DATA, N = TRUE, Ndistinct = TRUE, class = TRUE)

# Computing per-capita GDP growth using IMF WEO (October 2021) or World Bank WDI data
DATA[Year < 2020, .c(GDPCGR, GDPCGR_WB) := fgrowth(.(NGDPRPC, NY.GDP.PCAP.KD), g = ISO3, t = Year)] 
# Computing CPI inflation using IMF WEO (October 2021) or World Bank WDI data
DATA[Year < 2020, .c(INFL, INFL_WB) := .(PCPIPCH, fgrowth(FP.CPI.TOTL, g = ISO3, t = Year))]                                
# Generating IMF GDP per Capita in USD, using exchange rate from IFS
DATA[Year >= 1990 & Year < 2020, E_PA_2010 := ffirst(replace(ENDA_XDC_USD_RATE, Year != 2010L, NA), ISO3, 1L)] 
DATA[Year >= 1990 & Year < 2020, PCGDP := NGDPRPC / E_PA_2010] # For Somalia and Liberia it Seems the exchange rate is scaled wrongly..
source <- "Data Source: IMF World Economic Outlook, October 2021"

# Generating dataset with GDP per capita: IMF
PCGDP <- DATA %>% fsubset(ISO3 %in% am_countries$ISO3 & is.finite(PCGDP), 1:8, PCGDP, GDPCGR) 
fndistinct(PCGDP)
descr(PCGDP, cols = 9:10)

# Figure C1: Plot Log GDP per Capita Data for Africa: IMF and World Bank
DATA %>% 
  fsubset(ISO3 %in% am_countries$ISO3 & Year >= 1990 & Year < 2020, 
          1:8, PCGDP, PCGDP_WB = NY.GDP.PCAP.KD) %>% 
  melt(1:8, na.rm = TRUE) %>% 
  fsubset(is.finite(value) & value > 0) %>% 
  fmutate(variable = `levels<-`(variable, c("IMF (constant 2010 USD)", "World Bank (constant 2015 USD)"))) %>% 
  ggplot(aes(x = Year, y = log10(value), colour = variable)) + 
  geom_line() + 
  scale_color_brewer(palette = "Paired", direction = -1) +
  facet_wrap(~ Country, scales = "free_y", ncol = 6) +
  labs(y = "Log10 GDP Per Capita", colour = "Estimate:   ",
       caption = "Data Source: IMF WEO October 2021 and IFS, and World Development Indicators November 2021") +
  pretty_plot(caption.hjust = -0.05) +
  theme(legend.position = "top")

dev.copy(pdf, "Figures/Spectral Analysis/All_PCGDP_Log10.pdf", width = 11.69, height = 12)
dev.off()


# Estimate spectra ---------------------------

PCGDP_spectra <- PCGDP %>% 
  fsubset(GRPN(ISO3) > 10, PCGDP, ISO3) %$% 
  rsplit(log(PCGDP), ISO3) %>% 
  lapply(spec.pgram, plot = FALSE, detrend = TRUE, 
         taper = 0.15, spans = c(3, 7)) %>%
  lapply(scale_pgram, tovar = FALSE) %>% 
  lapply(with, cbind(frequency = freq, 
                     period = 1/freq, 
                     spec = setColnames(spec, snames))) %>% 
  unlist2d("ISO3", DT = TRUE)

# Uniform breaks
PCGDP_spectra[, Freq := cut(frequency, breaks = seq(0, 0.5, 1/30)+1e-5)]

# Plotting
PCGDP_spectra %>% psmat(spec ~ ISO3, ~ as.integer(Freq)) %>% log() %>% plot()

# Aggregating
PCGDP_spectra_agg <- PCGDP_spectra %>%
  fmutate(Period = fbetween(period, Freq)) %>%
  fselect(-ISO3, -Freq, -period) %>% 
  fgroup_by(Period) %>% 
  fmedian()

# Figure A1
PCGDP_spectra %>%  
  ggplot(aes(x = period, y = spec, group = ISO3)) + 
  geom_line() +
  geom_line(aes(x = Period, y = spec), data = PCGDP_spectra_agg, 
            colour = "red", size = 1.5, inherit.aes = FALSE) +
  scale_y_log10(labels = scales::trans_format("log10", scales::math_format(10^.x))) +
  scale_x_log10(n.breaks = 10) +
  annotation_logticks(sides = "lrtb") +
  pretty_plot() + 
  labs(x = expression(1/omega[j] ~ " (Period in Years)"), y = expression(I[s](omega[j]) ~ " (Scaled Spectral Density)"), 
       title = "Scaled Spectral Densities of Ln(GDP per Capita) in Africa", 
       caption = source)

dev.copy(pdf, "Figures/Spectral Analysis/Spectral_Densities_Period_Smooth.pdf", width = 8.7, height = 6)
dev.off()


# Spectra (variances vs GDP growth) ----------------------------------------------------

PCGDP_spectra_wide <- PCGDP_spectra %>% 
  fmutate(Period = signif(fbetween(period, Freq), 2)) %>%
  dcast(ISO3 ~ Period, value.var = "spec")

# Merging with medians and mads of GDP per Capita growth
PCGDP_spectra_wide %<>% merge(
  PCGDP[, .(PCGDP_growth_median = fmedian(GDPCGR), 
            PCGDP_growth_MAD = MAD(GDPCGR, na.rm = TRUE)), by = ISO3], 
  by = "ISO3", all.x = TRUE)

fbands <- gvr(PCGDP_spectra_wide, "_|ISO3", invert = TRUE, return = "names") 

# Figure A2:
# relationship with classical measures
oldpar <- par(mai = c(0.8, 0.7, 0.32, 0.22), mfrow = c(2, 1))
PCGDP_spectra_wide %>% {pwcor(.$PCGDP_growth_median, gv(., fbands))} %>% 
  barplot(las = 2, ylim = c(-0.2, 0.3), # Beautiful!
          main = expression(cor(I[s](omega[j]), med("%"*Delta*Y))), 
          xlab = "")
# Betas:
betas <- PCGDP_spectra_wide %>% {pwcov(.$PCGDP_growth_median, gv(., fbands))/fvar(gv(., fbands))}
betas %>% 
  barplot(las = 2, ylim = c(-350, 100), 
          main = expression(cov(I[s](omega[j]), med("%"*Delta*Y))/var(I[s](omega[j]))), 
          xlab = expression(1/omega[j] ~ " (Period in Years)"))
par(oldpar)

dev.copy(pdf, "Figures/Spectral Analysis/Period_Med_GDP_Corr.pdf", width = 8.27, height = 5.83)
dev.off()

# Correlation with the MAD: A bit odd to see stronger correlations at long periods
PCGDP_spectra_wide %>% {pwcor(.$PCGDP_growth_MAD, gv(., fbands))} %>% barplot(las = 2) 

# Estimating spectra on the growth rate
PCGDP_growth_spectra <- PCGDP %>% 
  fmutate(GDPCGR = GDPCGR / 100) %>%
  fsubset(GRPN(ISO3) > 10 & is.finite(GDPCGR)) %>% 
  rsplit(GDPCGR ~ ISO3) %>% 
  lapply(spec.pgram, plot = FALSE, detrend = TRUE, 
         taper = 0.15, spans = c(3, 7)) %>%
  lapply(scale_pgram, tovar = FALSE) %>% 
  lapply(with, cbind(frequency = freq, 
                     period = 1/freq, 
                     spec = setColnames(spec, snames))) %>% 
  unlist2d("ISO3", DT = TRUE)

# Uniform breaks
PCGDP_growth_spectra[, Freq := cut(frequency, breaks = seq(0, 0.5, 1/30)+1e-5)]

# Plotting
PCGDP_growth_spectra %>% psmat(spec ~ ISO3, ~ as.integer(Freq)) %>% log() %>% plot()

# Aggregating
PCGDP_growth_spectra_agg <- PCGDP_growth_spectra %>%
  fmutate(Period = fbetween(period, Freq)) %>%
  fselect(-ISO3, -Freq, -period) %>% 
  fgroup_by(Period) %>% 
  fmedian()

PCGDP_spectra_combined_agg <- PCGDP_spectra_agg %>% 
  frename(spec = spec_log, Period = period_log) %>% 
  merge(PCGDP_growth_spectra_agg %>% 
          frename(spec = spec_growth, Period = period_growth),
          by = "frequency") %>% 
  fmutate(Period = (period_log + period_growth) / 2)

# Figure A3: Median Spectral densities
PCGDP_spectra_combined_agg %>% 
  fselect(Period, "Ln(Y)" = spec_log, 
          'Growth(Y)' = spec_growth) %>% 
  melt(1, variable.name = "Function") %>% 

  ggplot(aes(x = Period, y = value, colour = Function)) + 
  geom_line() +
  scale_y_log10(labels = scales::trans_format("log10", function(x) scales::label_math(10^.x)(signif(x, 2)))) +
  scale_x_log10(n.breaks = 10) +
  scale_colour_manual(values = c("#000000", rgb(252, 186, 3, maxColorValue = 255))) +
  annotation_logticks(sides = "lrtb") +
  pretty_plot() + theme(plot.title = element_text(hjust = 0.5)) +
  labs(x = expression(1/omega[j] ~ " (Period in Years)"), y = expression(I[s](omega[j]) ~ " (Scaled Spectral Density)"), 
       title = "Median Spectral Density of FUN(GDP per Capita) in Africa", 
       caption = source)

dev.copy(pdf, "Figures/Spectral Analysis/Spectral_Densities_Period_Medians.pdf", width = 8.27, height = 5)
dev.off()


# Density of differences
dens_diff <- PCGDP_spectra_combined_agg %>%
  with(setNames(spec_growth/spec_log, signif(Period, 2)))
  
betas_filter <- -replace(betas, betas > 0, 0)

# Figure A4
barplot(betas_filter / sum(betas_filter), col = rgb(71, 71, 71, 255, maxColorValue = 255), 
        xlab = expression(1/omega[j] ~ " (Period in Years)"), ylab = "Normalized Weights/Coefficients")
barplot(rev(dens_diff) / sum(abs(dens_diff)), add = TRUE, 
        col = rgb(252, 186, 3, 180, maxColorValue = 255))
legend("topright", legend = c(expression(f^Delta*(omega[j]) ~ "       "), expression(f*(omega[j]))), 
       fill = c(rgb(252, 186, 3, 180, maxColorValue = 255), rgb(71, 71, 71, 255, maxColorValue = 255)), 
       bty = "n", ncol = 2, cex = 1.2)

dev.copy(pdf, "Figures/Spectral Analysis/Empirical_Filters.pdf", width = 8.27, height = 4.83)
dev.off()


# Now Correlations of Various volatility Indicators ------------------------

vol_measures <- PCGDP %>% 
  fmutate(GDPCGR = GDPCGR / 100) %>%
  fsubset(GRPN(ISO3) > 10 & is.finite(GDPCGR)) %>% 
  fgroup_by(ISO3) %>% 
  fsummarise(SD = fsd(GDPCGR),
             IQR = IQR(GDPCGR), 
             MAD = MAD(GDPCGR))

if(!identical(vol_measures$ISO3, PCGDP_spectra_wide$ISO3)) stop("Not equal")
vol_measures$HVI <- PCGDP_spectra_wide %>% fselect(`2`:`30`) %>% qM() %*% drop(betas_filter)
vol_measures$Median <- PCGDP_spectra_wide$PCGDP_growth_median / 100
if(!all.equal(vol_measures$MAD, PCGDP_spectra_wide$PCGDP_growth_MAD / 100)) stop("not equal")

# Correlations (not robust)
vol_measures %>% num_vars() %>% pwcor()
# Comedian
vol_measures %>% num_vars() %>% na_omit() %>% 
  robustbase::covComed() %>% extract2("cov") %>% 
  multiply_by(1000) %>% round(3)
# SDE
vol_measures %>% num_vars() %>% na_omit() %>% 
  rrcov::CovSde(prob = 0.9999, seed = set.seed(21)) %>% `@`("cov") %>% 
  multiply_by(1000) %>% round(3)

# Figure A5: Scatterplots using KS (2014) MM estimator
# LHS
chartcorr(num_vars(vol_measures), method = "robust")

dev.copy(pdf, "Figures/Spectral Analysis/Vol_Measures_Chartcorr.pdf", width = 7, height = 5)
dev.off()

# RHS
chartcorr(dapply(num_vars(vol_measures), log), method = "robust")

dev.copy(pdf, "Figures/Spectral Analysis/Log_Vol_Measures_Chartcorr.pdf", width = 7, height = 5)
dev.off()


