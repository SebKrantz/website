#########################################
# Africa's Great Moderation
# ---------------------------------------
# Replication Code for Section 4: 
# External, Financial, and Policy Factors
# ---------------------------------------
# By Sebastian Krantz (IfW Kiel)
#########################################

# This analysis was conducted using GNU R 4.1.0 for Windows

# Loading Packages
library(collapse)      # v1.8.9
library(data.table)    # v1.14.0
library(kit)           # v0.0.11
library(magrittr)      # v2.0.1
library(fixest)        # v0.11.0
library(africamonitor) # v0.2.1
library(ggplot2)       # v3.3.5
library(kableExtra)    # v1.3.4
# Also used: {countrycode} v1.2.0, {stringr} v1.5.0, {readxl} v1.4.2 and {plm} v2.4.1
# These are quite stable packages, I expect the code to run also with future versions

# Loading Data and Functions
DATA_Africa <- readRDS("Data/MACRO_DATA.rds") %>% 
  fsubset(ISO3 %in% am_countries$ISO3) %>% 
  frename(gsub, pat = ".", rep = "_", fixed = TRUE)

source("Code/functions.R")

# Computing per-capita GDP growth using IMF WEO (October 2021) or World Bank WDI data
DATA_Africa[Year < 2020, .c(GDPCGR, GDPCGR_WB) := fgrowth(.(NGDPRPC, NY_GDP_PCAP_KD), g = ISO2, t = Year)] 
# Computing CPI inflation using IMF WEO (October 2021) or World Bank WDI data
DATA_Africa[Year < 2020, .c(INFL, INFL_WB) := .(PCPIPCH, fgrowth(FP_CPI_TOTL, g = ISO2, t = Year))]   

namlab(DATA_Africa, N = TRUE)

####################################
# 4.1 External Environment
####################################


# Figure C18
DATA_Africa |> 
  na_omit(cols = .c(NY_GDP_MKTP_CD, SP_POP_TOTL)) |>
  fgroup_by(Year) |>
  fselect(TT_PRI_MRCH_XD_WD, BX_KLT_DINV_WD_GD_ZS, BX_TRF_PWKR_DT_GD_ZS, 
          GGXWDG_NGDP, DT_DOD_DECT_GN_ZS, DT_TDS_DECT_GN_ZS, 
          GDP = NY_GDP_MKTP_CD, POP = SP_POP_TOTL) %>% 
  frename(function(x) sub("Percent of GDP", "% of GDP", vlabels(.))[1:6], cols = 1:6) %>%
  { list(None = slt(., -GDP, -POP) |> fmedian() |> ftransformv(-1, frollmean, 5),
         GDP = slt(., -POP) |> fmedian(GDP, keep.w = FALSE) |> ftransformv(-1, frollmean, 5),
         POP = slt(., -GDP) |> fmedian(POP, keep.w = FALSE) |> ftransformv(-1, frollmean, 5)) 
  } %>% unlist2d(idcols = "Weights", id.factor = TRUE, DT = TRUE) |>
  fsubset(between(Year, 1990, 2019)) |>
  melt(1:2, na.rm = TRUE) |>
  ggplot(aes(x = Year, y = value, colour = Weights)) + geom_line() + 
  facet_wrap( ~ variable, scales = "free_y") +
  # scale_colour_manual(values = c("grey20", "orange")) +
  scale_y_continuous(n.breaks = 8) +
  labs(title = "Terms of Trade, FDI, Remittances and Debt in Africa, 1990-2019", 
       y = "5-Year Rolling Average of Cross-Country Median",
       caption = "Data Source: IMF and World Bank. Accessed through the africamonitor API.") +
  pretty_plot(base.size = 12, caption.hjust = -0.05) +
  theme(strip.text = element_text(face = "bold", size = 9, colour = "grey20"))

dev.copy(pdf, "Figures/Extra Figures/Debt_Flows_Levels_Weights.pdf", width = 11, height = 5.3)
dev.off()

# Computing within-country correlations with growth and inflation
ee_vars <- .c(NGDPRPC, PCPIPCH, TT_PRI_MRCH_XD_WD, BX_KLT_DINV_WD_GD_ZS, BX_TRF_PWKR_DT_GD_ZS, 
              GGXWDG_NGDP, DT_DOD_DECT_GN_ZS, DT_TDS_DECT_GN_ZS)

ee_data <- DATA_Africa %>% get_vars(c("ISO3", "Year", ee_vars))
# am_data(series = ee_vars, expand.date = TRUE, gen = "Year")
namlab(ee_data)
setrename(ee_data, NGDPRPC = PCGDP, PCPIPCH = INFL, 
          TT_PRI_MRCH_XD_WD = TOT, BX_KLT_DINV_WD_GD_ZS = FDI, 
          BX_TRF_PWKR_DT_GD_ZS = REM, GGXWDG_NGDP = GGDT, 
          DT_DOD_DECT_GN_ZS = EDT, DT_TDS_DECT_GN_ZS  = EDS)

# Simple aggregation
ee_data_agg <- ee_data |>
  fsubset(between(Year, 1990, 2019)) |>
  fgroup_by(ISO3) |>
  fmutate(PCGDP_G = fgrowth(PCGDP, t = Year)) |>
  fsummarise(across(INFL:PCGDP_G, fmedian), 
             PCGDP_MAD = mad(PCGDP_G, na.rm = TRUE), 
             INFL_MAD = mad(INFL, na.rm = TRUE)) 

qsu(ee_data_agg)

ee_data_agg |>
  num_vars() |>
  pwcor(w = NULL, P = TRUE) |> 
  extract(.c(PCGDP_G, PCGDP_MAD, INFL, INFL_MAD), .c(TOT, FDI, REM, GGDT, EDT, EDS), )

# Rolling aggregation
ee_data_roll <- ee_data |>
  roworder(ISO3, Year) |>
  fmutate(PCGDP_G = fgrowth(PCGDP, g = ISO3, t = Year)) |>
  fsubset(between(Year, 1981, 2019)) |>
  fgroup_by(ISO3) |>
  fmutate(across(INFL:PCGDP_G, frollmean, 10),
          across(c(PCGDP_G, INFL), list(MED = function(x) frollapply(x, 10, median, na.rm = TRUE), 
                                        MAD = function(x) frollapply(x, 10, mad, na.rm = TRUE)))) |>
  fungroup() |>
  na_omit(cols = c("PCGDP_G", "INFL"))

qsu(ee_data_roll)

# Table C11
ee_data_roll |>
  fsubset(between(Year, 1990, 2019)) |>
  findex_by(ISO3, Year) |>
  STD(stub = FALSE) |>
  D(stub = FALSE) |>
  num_vars() |>
  pwcor(w = NULL, P = TRUE) |> 
  extract(.c(PCGDP_G_MED, PCGDP_G_MAD, INFL_MED, INFL_MAD), .c(TOT, FDI, REM, GGDT, EDT, EDS), ) |>
  print(digits = 3, return = TRUE) |>
  kbl("latex", digits = 3, booktabs = TRUE)


# External Environment: volatility -------------------------------------------------

# Figure C19
DATA_Africa %>%
  roworder(ISO3, Year) %>%
  fselect(ISO3, Year, ENDA_XDC_USD_RATE, TT_PRI_MRCH_XD_WD, BN_GSR_MRCH_CD, 
          BX_KLT_DINV_CD_WD, BX_TRF_PWKR_CD_DT, BCA, 
          NY_GDP_MKTP_CD, SP_POP_TOTL) %>% 
  frename(NY_GDP_MKTP_CD = GDP, SP_POP_TOTL = POP, 
          ENDA_XDC_USD_RATE = "Exchange Rate, Period Average (LCU per US$)",
          TT_PRI_MRCH_XD_WD = "Net Barter Terms of Trade Index (2000 = 100)",
          BX_KLT_DINV_CD_WD = "Foreign Direct Investment, Net Inflows (US$)",
          BX_TRF_PWKR_CD_DT = "Personal Remittances, Received (US$)",
          BCA = "Current Account Balance (US$ Bn)",
          BN_GSR_MRCH_CD = "Merchandise Trade Balance (US$)") %>%
  ftransformv(3:8, function(x, g) BY(fgrowth(x, g = g), g, frollapply, 10, IQR, na.rm = TRUE), 
              g = GRP(ISO3)) %>%
  na_omit(cols = .c(GDP, POP)) %>%
  fgroup_by(Year) %>%
  num_vars() %>%
  { list(None = slt(., -GDP, -POP) |> fmedian() |> ftransformv(-1, frollmean, 5),
         GDP = slt(., -POP) |> fmedian(GDP, keep.w = FALSE) |> ftransformv(-1, frollmean, 5),
         POP = slt(., -GDP) |> fmedian(POP, keep.w = FALSE) |> ftransformv(-1, frollmean, 5)) 
  } %>% unlist2d(idcols = "Weights", id.factor = TRUE, DT = TRUE) |>
  fsubset(between(Year, 1990, 2019)) |>
  melt(1:2, na.rm = TRUE) |>
  ggplot(aes(x = Year, y = value, colour = Weights)) + geom_line() + 
  facet_wrap( ~ variable, scales = "free_y") +
  scale_y_continuous(n.breaks = 8) +
  labs(title = "Volatility of the Growth Rate of Selected External Variables in Africa, 1990-2019", 
       y = "Rolling IQR of the Grrowth Rate*",
       caption = "  Data Source: IMF and World Bank. Accessed through the africamonitor API.\n*Note: Plots show a 5-year MA of the cross-country (weighted) median of a 10-year rolling IQR of the growth rate of the series.") +
  pretty_plot(base.size = 12, caption.hjust = -0.05) + 
  theme(strip.text = element_text(face = "bold", size = 9, colour = "grey20"))

dev.copy(pdf, "Figures/Extra Figures/Debt_Flows_Growth_Weights.pdf", width = 11, height = 5.3)
dev.off()


# Computing within-country correlations with growth and inflation
ee_vol_vars <- .c(NGDPRPC, PCPIPCH, ENDA_XDC_USD_RATE, 
                  TT_PRI_MRCH_XD_WD, BN_GSR_MRCH_CD, BX_KLT_DINV_CD_WD, 
                  BX_TRF_PWKR_CD_DT, BCA) # GGXCNL)

ee_vol_data <- DATA_Africa %>% get_vars(c("ISO3", "Year", ee_vol_vars))
# ee_vol_data <- am_data(series = .c(NGDPRPC, PCPIPCH, ENDA_XDC_USD_RATE_A, TT_PRI_MRCH_XD_WD, BX_KLT_DINV_CD_WD, 
#                                    BX_TRF_PWKR_CD_DT, BCA, BN_GSR_MRCH_CD), expand.date = TRUE, gen = "Year") # GGXCNL
namlab(ee_vol_data)
setrename(ee_vol_data, 
          NGDPRPC = PCGDP, PCPIPCH = INFL, 
          ENDA_XDC_USD_RATE = E_PA, 
          TT_PRI_MRCH_XD_WD = TOT, 
          BN_GSR_MRCH_CD = TB, 
          BX_KLT_DINV_CD_WD = FDI, 
          BX_TRF_PWKR_CD_DT = REM, BCA = CAB) #, GGXCNL = GBB)

ee_vol_data_roll <- ee_vol_data |>
  roworder(ISO3, Year) |>
  ftransformv(c(PCGDP, E_PA:CAB), fgrowth, g = ISO3, t = Year, apply = FALSE) |>
  fsubset(between(Year, 1981, 2019)) |>
  fgroup_by(ISO3) |> 
  fmutate(across(c(PCGDP, INFL), list(MED = function(x) frollapply(x, 10, median, na.rm = TRUE), 
                                      MAD = function(x) frollapply(x, 10, mad, na.rm = TRUE))),
          across(PCGDP:CAB, frollapply, 10, mad)) |>
  fungroup() |>
  na_omit(cols = c("PCGDP", "INFL"))


descr(ee_vol_data_roll)

# Table C12
ee_vol_data_roll |>
  fsubset(between(Year, 1981, 2019)) |>
  num_vars() |>
  pwcor(w = NULL, P = TRUE) |> 
  extract(.c(PCGDP_MED, PCGDP_MAD, INFL_MED, INFL_MAD), .c(E_PA, TOT, TB, FDI, REM, CAB), ) |> #, GBB
  print(digits = 3, return = TRUE) |>
  kbl("latex", digits = 3, booktabs = TRUE)



# Reserves and Financial Deepening -----------------------------------------

rvars <- .c(NGSD_NGDP, # GNS in % of GDP, IMF  # NID_NGDP, # Investment
            FI_RES_TOTL_DT_ZS, # Total reserves in % of External debt
            FI_RES_TOTL_MO, # Total reserves in months of imports
            FS_AST_PRVT_GD_ZS, # Domestic Credit to Private Sector (% of GDP)
            FM_LBL_BMNY_GD_ZS, # Broad Money (% of GDP)
            FD_RES_LIQU_AS_ZS) # Bank Liquid Reserves to Bank Assets Ratio (%)

rdata <- DATA_Africa %>% get_vars(c("ISO3", "Year", "NY_GDP_MKTP_CD", "SP_POP_TOTL", rvars))
# rdata <- am_data(series = c(rvars, .c(NY_GDP_MKTP_CD, SP_POP_TOTL)))              

rdata %>% 
  na_omit(cols = .c(NY_GDP_MKTP_CD, SP_POP_TOTL)) %>%
  fgroup_by(Year) %>% 
  get_vars(c(rvars, "NY_GDP_MKTP_CD", "SP_POP_TOTL")) %>% 
  relabel(NY_GDP_MKTP_CD = "GDP", SP_POP_TOTL = "POP", NGSD_NGDP = "Gross National Savings (% of GDP)") %>% 
  set_names(stringr::str_wrap(vlabels(.), 45)) %>% {
    list(None = slt(., -GDP, -POP) %>% fmean(),
         GDP = slt(., -POP) %>% fmean(GDP, keep.w = FALSE), 
         POP = slt(., -GDP) %>% fmean(POP, keep.w = FALSE))
  } %>% unlist2d("Weights", DT = TRUE, id.factor = TRUE) %>%
  ftransformv(-(1:2), BY, Weights, frollmean, 5, apply = FALSE) %>%
  fsubset(between(Year, 1990, 2019)) %>%
  melt(1:2, na.rm = TRUE) %>% 
  ggplot(aes(x = Year, y = value, colour = Weights)) +
  geom_line() +
  facet_wrap(~ variable, scales = "free_y") +
  scale_y_continuous(n.breaks = 8) +
  labs(title = "Total Reserves and Financial Depth in Africa, 1990-2019", 
       y = "5-Year Rolling Average of Cross-Country Mean",
       caption = "  Data Source: IMF and World Bank. Accessed through the africamonitor API.") +
  pretty_plot(base.size = 12, caption.hjust = -0.05) + 
  theme(strip.text = element_text(face = "bold", size = 9, colour = "grey20"))

dev.copy(pdf, "Figures/Extra Figures/Reserves_FinDepth_Weights_GNS.pdf", width = 11, height = 5.3)
dev.off()

# Computing within-country correlations with growth and inflation
fd_data <- DATA_Africa %>% get_vars(c("ISO3", "Year", "NGDPRPC", "PCPIPCH", rvars))   
# fd_data <- am_data(series = .c(NGDPRPC, PCPIPCH, NGSD_NGDP, FI_RES_TOTL_DT_ZS, FI_RES_TOTL_MO, 
#                                FS_AST_PRVT_GD_ZS, FM_LBL_BMNY_GD_ZS, FD_RES_LIQU_AS_ZS), 
#                    expand.date = TRUE, gen = "Year")
namlab(fd_data)
setrename(fd_data, NGDPRPC = PCGDP, PCPIPCH = INFL, 
          NGSD_NGDP = GNS, FI_RES_TOTL_DT_ZS = TR_EDT, FI_RES_TOTL_MO = TR_MIM, 
          FS_AST_PRVT_GD_ZS = PSC, FM_LBL_BMNY_GD_ZS = BM, FD_RES_LIQU_AS_ZS = BLR_A)

fd_data_roll <- fd_data |>
  roworder(ISO3, Year) |>
  fmutate(PCGDP_G = fgrowth(PCGDP, g = ISO3, t = Year)) |>
  fsubset(between(Year, 1981, 2019)) |>
  fgroup_by(ISO3) |>
  fmutate(across(INFL:PCGDP_G, frollmean, 10),
          across(c(PCGDP_G, INFL), list(MED = function(x) frollapply(x, 10, median, na.rm = TRUE), 
                                        MAD = function(x) frollapply(x, 10, mad, na.rm = TRUE)))) |>
  fungroup() |>
  na_omit(cols = c("PCGDP_G", "INFL"))

qsu(fd_data_roll)

# Table C13
fd_data_roll |>
  fsubset(between(Year, 1990, 2019)) |>
  findex_by(ISO3, Year) |>
  STD(stub = FALSE) |>
  D(stub = FALSE) |>
  num_vars() |>
  pwcor(w = NULL, P = TRUE) |> 
  extract(.c(PCGDP_G_MED, PCGDP_G_MAD, INFL_MED, INFL_MAD), .c(GNS, TR_EDT, TR_MIM, PSC, BM, BLR_A), ) |>
  print(digits = 3, return = TRUE) |>
  kbl("latex", digits = 3, booktabs = TRUE)


####################################
# 4.2 Macroeconomic Policies
####################################


# Inflation Targeters ---------------------------------------------

infl_targets <- DATA_Africa %>% fsubset(ISO3 %in% c("ZAF", "GHA", "UGA", "SYC"), ISO3, Year, PCPIPCH)
# infl_targets <- am_data(ctry = c("ZAF", "GHA", "UGA", "SYC"), series = "PCPIPCH", 
#                         expand.date = TRUE, gen = "Year", keep.date = FALSE)


infl_targets[, IT := (ISO3 == "ZAF" & Year >= 1999) | 
                     (ISO3 == "GHA" & Year >= 2007) | 
                     (ISO3 == "UGA" & Year >= 2011) | 
                     (ISO3 == "SYC" & Year >= 2019) ]

infl_targets %>% 
  merge(fselect(am_countries, ISO3, Country), all.x = TRUE) %>% 
  fsubset(between(Year, 1990, 2020), Country, Year, PCPIPCH, IT) %>% 
  na_omit(cols = "PCPIPCH") %>%
  ggplot(aes(x = Year, y = PCPIPCH, colour = IT)) +
  geom_line() + facet_wrap( ~ Country, scales = "free") +
  labs(title = "Inflation Targeters in Africa, 1990-2020", y = "CPI Inflation",
       caption = "Data Source: IMF World Economic Outlook, October 2021") +
  pretty_plot(caption.hjust = -0.05)

dev.copy(pdf, "Figures/African_Inflation_Targeters.pdf", width = 10, height = 6)
dev.off()

# Exchange Rate Arrangements ----------------------------------------

ERA <- readxl::read_excel("Data/Policies/Exchange Rate Regimes/ERA_Classification_Monthly_1940-2019.xlsx", sheet = "Coarse")
names(ERA) <- ERA %>% ss(4:5) %>% dapply(function(x) paste(na_rm(x), collapse = " "))
ERA %<>% ss(-(1:6), -1) %>% 
  fmutate(Country = africamonitor::am_as_date(Country)) %>% 
  frename(Country = Date) %>% 
  ftransformv(-1, as.numeric) %>% 
  qDT() %>% 
  melt(1, variable.name = "Country", value.name = "Value", na.rm = TRUE) %>% 
  roworderv()

qtab(ERA$Value)
settransform(ERA, Year = year(Date), 
             Peg = Value == 1,
             Crawling_Peg = Value == 2,
             Crawling_Band = Value == 3,
             Float = Value == 4, 
             Freely_Falling = Value == 5,
             Dual_Market = Value > 5)
             # Other = Value > 4) 

# Exchange Rate arrangements worldwide
ERA %>% 
  fgroup_by(Date) %>% 
  fsummarise(across(Peg:Dual_Market, fmean)) %>% 
  melt(1) %>% 
  ggplot(aes(x = Date, y = value, fill = variable)) + geom_area(position = "fill")


# Fix some country names  
ERA %<>% fmutate(Country = recode_char(as.character(Country), regex = TRUE,
                                       Ivoire = "Côte d'Ivoire", 
                                       "Central African" = "Central African Republic",
                                       "Congo Dem" = "Democratic Republic of the Congo",
                                       "Congo Rep" = "Republic of Congo",
                                       "Guinea Bissau" = "Guinea-Bissau",
                                       Swaziland = "Eswatini"),
                 ISO3 = countrycode::countryname(Country, "iso3c")) %>% # countrycode v1.2.0
         colorder(Country, ISO3)

# Exchange Rate arrangements in Africa  
ERA %>% 
  fsubset(ISO3 %in% am_countries$ISO3 & Year >= 1990) %>% 
  fgroup_by(Date) %>% 
  logi_vars() %>% fmean() %>% 
  frename(sub, pat = "_", rep = " ") %>%
  melt(1, variable.name = "Arrangement") %>% 
  ggplot(aes(x = Date, y = value, fill = Arrangement)) + 
  geom_area(position = "fill", alpha = 0.8) +
  scale_y_continuous(expand = c(0,0), labels = scales::percent) +
  scale_x_date(expand = c(0,0), breaks = scales::pretty_breaks(10)) +
  labs(title = "Exchange Rate Regimes in Africa, 1990-2019", y = "Share of 53 African Countries",
       caption = "Data Source: Ilzetzki, Reinhart and Rogoff (2019)") + 
  pretty_plot()

dev.copy(pdf, "Figures/African_Exchange_Rate_Regimes.pdf", width = 9, height = 5)
dev.off()
# -> Free floats peaked in the 90's and declined thereafter...

ERA_DATA_Africa <- DATA_Africa %>% 
  fselect(Country, ISO2, ISO3, Year, GDPCGR, GDPCGR_WB, 
          INFL, INFL_WB, CPI_WB = FP_CPI_TOTL, E = ENDA_XDC_USD_RATE) %>%
  merge(ERA %>% gby(ISO3, Year) %>% gv(is.logical) %>% fmean(), 
        by = c("ISO3", "Year"), all.x = TRUE)

N <- 15
ERA_DAT_Africa_roll = ERA_DATA_Africa[order(ISO3, Year), 
                       c(list(Year = Year,
                              GDPCGR_median = frollapply(GDPCGR, N, median), 
                              INFL_median = frollapply(INFL, N, median),
                              GDPCGR_mad = frollapply(GDPCGR, N, MAD), 
                              INFL_mad = frollapply(INFL, N, MAD), 
                              GDPCGR_WB_median = frollapply(GDPCGR_WB, N, median), 
                              INFL_WB_median = frollapply(INFL_WB, N, median),
                              GDPCGR_WB_mad = frollapply(GDPCGR_WB, N, MAD), 
                              INFL_WB_mad = frollapply(INFL_WB, N, MAD)), 
                         lapply(gvr(.SD, "Peg|Band|Float|Falling|Dual"), frollmean, N)),
                       by = ISO3][is.finite(GDPCGR_mad) | is.finite(INFL_mad)] 

print(pwcor(gvr(ERA_DAT_Africa_roll, "WB"), gvr(ERA_DAT_Africa_roll, "L_m|R_m")), digits = 4)


# See if varying 
ERA_DATA_Africa %>% 
  fgroup_by(ISO3) %>% 
  fselect(Peg:Dual_Market) %>% 
  varying(any_group = FALSE) %>% 
  logi_vars() %>% fsum()

# Average group size
ERA_DATA_Africa %>% 
  fgroup_by(Year) %>% 
  num_vars() %>% fsum() %>%
  fsubset(Year >= 1990, Peg:Dual_Market) %>% fmean() 

# Testing for serial correlation...
plm <- plm::plm # plm v2.4.1
plm::pdwtest(GDPCGR ~ Crawling_Peg + Crawling_Band + Float + Freely_Falling + Dual_Market, 
        data = plm::pdata.frame(ERA_DATA_Africa[between(Year, 1990, 2019)], index = c("ISO3", "Year")))
plm::pbgtest(GDPCGR ~ Crawling_Peg + Crawling_Band + Float + Freely_Falling + Dual_Market, 
        data = plm::pdata.frame(ERA_DATA_Africa[between(Year, 1990, 2019)], index = c("ISO3", "Year")))
plm::pwfdtest(GDPCGR ~ Crawling_Peg + Crawling_Band + Float + Freely_Falling + Dual_Market, 
         data = plm::pdata.frame(ERA_DATA_Africa[between(Year, 1990, 2019)], index = c("ISO3", "Year")))

# Level regressions (not reported)
est_feols = feols(c(GDPCGR, INFL) ~ Crawling_Peg + Crawling_Band + Float + psum(Freely_Falling + Dual_Market) | csw(, ISO3, Year), 
                  data = ERA_DATA_Africa, panel.id = c("ISO3", "Year"), subset = ~ Year >= 1990)

se(est_feols, cluster = "ISO3")
se(est_feols, cluster = c("ISO3", "Year"))
se(est_feols, vcov = "DK")
se(est_feols, vcov = DK ~ ssc(adj = TRUE, cluster.adj = TRUE)) # Same thing...
summary(est_feols, cluster = "ISO3")
summary(est_feols, cluster = c("ISO3", "Year"))
summary(est_feols, vcov = DK ~ ssc(adj = FALSE, cluster.adj = FALSE))

esttex(est_feols[c(1,3,5,2,4,6)], 
       fixef_sizes = TRUE, vcov = "DK", # cluster = c("ISO3", "Year"),
       fixef_sizes.simplify = FALSE, digits.stats = 3,
       title = "Panel-Regression in Levels")

# Rolling Panel

# Average group size
ERA_DAT_Africa_roll %>% 
  fgroup_by(Year) %>% 
  num_vars() %>% fsum() %>%
  fsubset(between(Year, 2005, 2019), Peg:Dual_Market) %>% 
  fmean() %>% round(1)

# Specification tests
tmp = plm::pdata.frame(ERA_DAT_Africa_roll[between(Year, 2005, 2019)], index = c("ISO3", "Year"))
plm::phtest(GDPCGR_mad ~ Crawling_Peg + Crawling_Band + Float + psum(Freely_Falling, Dual_Market), data = tmp)
plm::phtest(GDPCGR_mad ~ Crawling_Peg + Crawling_Band + Float + psum(Freely_Falling, Dual_Market), data = tmp, effect = "twoways")
plm::pdwtest(GDPCGR_mad ~ Crawling_Peg + Crawling_Band + Float + psum(Freely_Falling, Dual_Market), data = tmp)
plm::pbgtest(GDPCGR_mad ~ Crawling_Peg + Crawling_Band + Float + psum(Freely_Falling, Dual_Market), data = tmp)
plm::pwfdtest(GDPCGR_mad ~ Crawling_Peg + Crawling_Band + Float + psum(Freely_Falling, Dual_Market), data = tmp)
rm(tmp)

# Now the rolling regressions (Table C14)
est_feols_mad = feols(c(GDPCGR_mad, INFL_mad) ~ Crawling_Peg + Crawling_Band + Float + psum(Freely_Falling, Dual_Market) | csw(, ISO3, Year), 
                      data = ERA_DAT_Africa_roll, panel.id = c("ISO3", "Year"), subset = ~ between(Year, 2005, 2019)) 
  
summary(est_feols_mad, cluster = "ISO3")
summary(est_feols_mad, cluster = c("ISO3", "Year"))
summary(est_feols_mad, vcov = "NW")
summary(est_feols_mad, vcov = "DK")

# Table C14
esttex(est_feols_mad[c(1,3,5,2,4,6)], 
       fixef_sizes = TRUE, vcov = "DK", 
       fixef_sizes.simplify = FALSE, digits.stats = 3,
       title = "Panel-Regression in Rolling-15-Year Panel")



# Investigating Pass-Through Channel (not reported, inconclusive) -----------

sr_pass_through <- function(x, e = "E") {
  co <- coef(x)
  nam <- names(co)
  names(co) <- NULL
  co[grep(e, nam, fixed = TRUE)[1L]]
}

lr_pass_through <- function(x, e = "E", cpi = "CPI") {
  co <- coef(x)
  nam <- names(co)
  names(co) <- NULL
  sum(co[grep(e, nam, fixed = TRUE)]) / (1-sum(co[grep(cpi, nam, fixed = TRUE)]))
}

# Using the CPI: dynamic FE estimator
EPS_reg_cpi <- feols(log(CPI_WB) ~ l(log(CPI_WB), 1:3) + l(log(E), 0:3), 
                  data = ERA_DATA_Africa[between(Year, 1990, 2019)], 
                  fixef = c("ISO3", "Year"), panel.id = c("ISO3", "Year"))
# Short-term pass-through
sr_pass_through(EPS_reg_cpi)
# Long-run pass-through
lr_pass_through(EPS_reg_cpi)

# Using inflation: panel-first-difference estimator 
EPS_reg_infl <- feols(INFL ~ l(INFL, 1:2) + l(G(E, logdiff = TRUE), 0:2), 
                  data = ERA_DATA_Africa[between(Year, 1990, 2019)], 
                  panel.id = c("ISO3", "Year"))
# Short-term pass-through
sr_pass_through(EPS_reg_infl)
# Long-run pass-through
lr_pass_through(EPS_reg_infl, cpi = "INFL")

# Now for individual countries
tmp <- ERA_DATA_Africa[between(Year, 1990, 2019) & is.finite(E) & is.finite(CPI_WB)]
EPS_regs <-  rsplit(tmp, Year + CPI_WB + E ~ ISO3) %>% 
  get_elem(function(x) fnrow(x) > 20, recursive = FALSE) %>% 
  lapply(lm, formula = log(CPI_WB) ~ L(log(CPI_WB), 1:2) + L(log(E), 0:2))

# Coefficients
EPS_regs %>% lapply(coeftable) %>% lapply(round, 3)
# Results data frame
PT_res <- cbind(SRPT = EPS_regs %>% sapply(sr_pass_through),
                LRPT = EPS_regs %>% sapply(lr_pass_through)) %>% qDT("ISO3") %>% na_omit()
# Now averaging ERA: 
ERA_agg <- tmp %>% fgroup_by(ISO3) %>% fselect(Peg:Dual_Market) %>% fmean() %>% 
  ftransform(FF_DM = Freely_Falling + Dual_Market, Freely_Falling = NULL, Dual_Market = NULL)
psum(num_vars(ERA_agg)) # Check
# Merging
PT_res %<>% merge(ERA_agg, by = "ISO3")

# Now regressions of pass-though on regimes: Peg is base category
summary(lm(SRPT ~ Crawling_Peg + Crawling_Band  + Float + FF_DM, PT_res))
summary(lm(LRPT ~ Crawling_Peg + Crawling_Band  + Float + FF_DM, PT_res)) # This appears noisy


# Same with Inflation
tmp <- ERA_DATA_Africa[between(Year, 1990, 2019) & is.finite(G(E, logdiff = TRUE)) & is.finite(INFL)]
EPS_regs <-  rsplit(tmp, Year + INFL + E ~ ISO3) %>% 
  get_elem(function(x) fnrow(x) > 20, recursive = FALSE) %>% 
  lapply(lm, formula = INFL ~ L(INFL) + L(G(E, logdiff = TRUE), 0:1))

# Coefficients
EPS_regs %>% lapply(coeftable) %>% lapply(round, 3)
# Results data frame
PT_res <- cbind(SRPT = EPS_regs %>% sapply(sr_pass_through),
                LRPT = EPS_regs %>% sapply(lr_pass_through)) %>% qDT("ISO3") %>% na_omit()
# Now averaging ERA: 
ERA_agg <- tmp %>% fgroup_by(ISO3) %>% fselect(Peg:Dual_Market) %>% fmean() %>% 
  ftransform(FF_DM = Freely_Falling + Dual_Market, Freely_Falling = NULL, Dual_Market = NULL)
psum(num_vars(ERA_agg)) # Check
# Merging
PT_res %<>% merge(ERA_agg, by = "ISO3")

# Now regressions of pass-though on regimes: Peg is base category
summary(lm(SRPT ~ Crawling_Peg + Crawling_Band  + Float + FF_DM, PT_res))
summary(lm(LRPT ~ Crawling_Peg + Crawling_Band  + Float + FF_DM, PT_res))

# Overall: More liberal regimes seem to be associated with reduced pass-through in this setting, but results are insignificant. 


# Macroprudential Regulation --------------------------------------------

## FKRSU 2021: CAPITAL CONTROL MEASURES: A NEW DATASET
FKRSU_Africa <- readxl::read_excel("Data/Policies/FKRSU Macroprudential Database/2021-FKRSU-Update-12-08-2021.xlsx", sheet = "DATASET") %>% 
  fsubset(code_wdi %in% am_countries$ISO3 | code_ifs %in% am_countries$IMF)
qsu(FKRSU_Africa)
fndistinct(FKRSU_Africa)

# Figure D1 (separate online Appendix D)
FKRSU_Africa %>% fselect(country, year, ka, kai, kao) %>% 
  qDT() %>% melt(1:2) %>%
  ggplot(aes(x = year, y = value, colour = variable)) + 
  geom_line() + facet_wrap( ~country)

dev.copy(pdf, "Figures/African_MacroPrudential_Measures_Countries.pdf", width = 11.69, height = 8.27)
dev.off()

# Figure C23
FKRSU_Africa %>% 
  fgroup_by(year) %>% 
  fselect(ka, kai, kao) %>% 
  fmean() %>% 
  frename(ka = Overall, kai = Inflow, kao = Outflow) %>%
  # ftransformv(-year, frollmean, 10, na.rm = TRUE) %>%
  qDT() %>% melt(1, variable.name = "Type", na.rm = TRUE) %>% 
  ggplot(aes(x = year, y = value, colour = Type)) + 
  geom_line() + 
  labs(title = "Macroprudential Policy Measures in Africa, 1995-2019", 
       y = "Average Across 18 African Countries", x = "Year", 
       caption = "Data Source: Fernandez, Klein, Rebucci, Schindler and Uribe (2016, 2021)") + 
  pretty_plot()

dev.copy(pdf, "Figures/African_MacroPrudential_Measures.pdf", width = 8, height = 4)
dev.off()
# -> Not really much development

# Figure C24: Disaggregated Total Restrictions
FKRSU_Africa %>% 
  fgroup_by(year) %>% 
  fselect(eq,bo,mm,ci,de,cc,fc,gs,di,re) %>% 
  fmean() %>%
  frename(eq = Equity, bo = Bond, mm = "Money Market", ci = "Collective Investments",
          de = Derivatives, cc = "Commercial Credits", fc = "Financial Credits", 
          gs = Guarantees, di = "Direct Investment (FDI)", re = "Real Estate") %>%
  ftransformv(-year, frollmean, 10, na.rm = TRUE) %>%
  qDT() %>% melt(1, variable.name = "Type", na.rm = TRUE) %>% 
  ggplot(aes(x = year, y = value, colour = Type)) + 
  scale_colour_manual(values = sub("#00FF66", "#00CC66", rainbow(10))) +
  scale_x_continuous(limits = c(2004, 2020), n.breaks = 6) +
  geom_line() + 
  labs(title = "Disaggregated Overall Macroprudential Restrictions in Africa, 1995-2019", 
       y = "10-Year MA of Avg. of 18 African Countries", x = "Year", 
       caption = "Data Source: Fernandez, Klein, Rebucci, Schindler and Uribe (2016, 2021)") + 
  pretty_plot()

dev.copy(pdf, "Figures/African_MacroPrudential_Measures_DA.pdf", width = 9, height = 4.5)
dev.off()


# Merging with DATA
all(funique(FKRSU_Africa$code_wdi) %in% DATA_Africa$ISO3)

FKRSU_DATA_Africa <- DATA_Africa %>% 
  fselect(Country, ISO2, ISO3, Year, GDPCGR, GDPCGR_WB, INFL, INFL_WB) %>%
  merge(FKRSU_Africa, by.x = c("ISO3", "Year"), by.y = c("code_wdi", "year"))

# See if varying 
FKRSU_DATA_Africa %>% 
  fgroup_by(ISO3) %>% 
  fselect(ka, kai, kao) %>% 
  varying(any_group = FALSE) %>% 
  logi_vars() %>% fsum()

# # Levels Estimates 
# feols(c(GDPCGR, INFL) ~ ka | csw(, ISO3, Year), data = FKRSU_DATA_Africa, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# feols(c(GDPCGR, INFL) ~ kai + kao | csw(, ISO3, Year), data = FKRSU_DATA_Africa, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# feols(c(GDPCGR_WB, INFL_WB) ~ ka | csw(, ISO3, Year), data = FKRSU_DATA_Africa, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# feols(c(GDPCGR_WB, INFL_WB) ~ kai + kao | csw(, ISO3, Year), data = FKRSU_DATA_Africa, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# # -> Mildly significant

# Rolling panel:
N <- 10
FKRSU_DATA_Africa_roll <- FKRSU_DATA_Africa[order(ISO3, Year), 
     c(list(Year = Year,
            GDPCGR_median = frollapply(GDPCGR, N, median), 
            INFL_median = frollapply(INFL, N, median),
            GDPCGR_mad = frollapply(GDPCGR, N, MAD), 
            INFL_mad = frollapply(INFL, N, MAD),
            GDPCGR_WB_median = frollapply(GDPCGR_WB, N, median), 
            INFL_WB_median = frollapply(INFL_WB, N, median),
            GDPCGR_WB_mad = frollapply(GDPCGR_WB, N, MAD), 
            INFL_WB_mad = frollapply(INFL_WB, N, MAD)), 
       lapply(fselect(.SD, ka, kai, kao, eq,bo,mm,ci,de,cc,fc,gs,di,re), frollmean, N)),
     by = ISO3][is.finite(GDPCGR_mad) | is.finite(INFL_mad)] 

print(pwcor(gvr(FKRSU_DATA_Africa_roll, "WB"), gvr(FKRSU_DATA_Africa_roll, "L_m|R_m")), digits = 4)

# # Rolling estimates
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ ka | csw(, ISO3, Year), 
#       data = FKRSU_DATA_Africa_roll, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ kai + kao | csw(, ISO3, Year), 
#       data = FKRSU_DATA_Africa_roll, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ ka | csw(, ISO3, Year), 
#       data = FKRSU_DATA_Africa_roll, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ kai + kao | csw(, ISO3, Year), 
#       data = FKRSU_DATA_Africa_roll, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# 
# # With all control measures, only volatility
# feols(c(GDPCGR_mad, INFL_mad) ~ eq + bo + mm + ci + de + cc + fc + gs + di + re | csw(, ISO3, Year), 
#       data = FKRSU_DATA_Africa_roll, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")
# feols(c(GDPCGR_WB_mad, INFL_WB_mad) ~ eq + bo + mm + ci + de + cc + fc + gs + di + re | csw(, ISO3, Year), 
#       data = FKRSU_DATA_Africa_roll, panel.id = .c(ISO3, Year)) %>% etable(vcov = "DK")

# Table C15: Top Half
feols(c(GDPCGR_mad, INFL_mad) ~ ka | csw(, ISO3, Year), 
      data = FKRSU_DATA_Africa_roll, panel.id = .c(ISO3, Year)) %>% 
  get_vars(c(1,3,5,2,4,6)) %>% 
  esttex(fixef_sizes = TRUE, vcov = "DK", fixef_sizes.simplify = FALSE, digits.stats = 3,
         title = "Panel-Regression in Rolling-10-Year Panel")

# Table C15: Bottom Half
feols(c(GDPCGR_mad, INFL_mad) ~ kai + kao | csw(, ISO3, Year), 
      data = FKRSU_DATA_Africa_roll, panel.id = .c(ISO3, Year)) %>% 
  get_vars(c(1,3,5,2,4,6)) %>% 
  esttex(fixef_sizes = TRUE, vcov = "DK", fixef_sizes.simplify = FALSE, digits.stats = 3,
         title = "Panel-Regression in Rolling-10-Year Panel")



# Fiscal Rules, 1985-2021 ----------------------------------------------------------------

FR21 <- readxl::read_xlsx("Data/Policies/Fiscal Rules, 1985-2021/IMF Fiscal Rules Dataset 1985 - 2021 - January 2022 rev May.xlsx",
                          sheet = "Rules_Clean", .name_repair = "none")
names(FR21) <- FR21 %>% ss(1:4) %>% dapply(function(x) paste(na_rm(x), collapse = "_"))
FR21 %<>% ss(-(1:4)) %>% sbt(!is.na(CID)) %>% tfmv(c(-Country, -(Change_ER:N_Num_Any)), as.numeric)
FR21 %>% slt(ER:DR) %>% replace_NA(set = TRUE)
settfm(FR21, Country = trimws(Country))
settfmv(FR21, Type_ER:Type_DR, function(x) structure(as.integer(x) + 1L, levels = c("National", "Supranational", "Both"), class = "factor"))
tfm(FR21) <- FR21 %>% slt(Type_ER:Type_DR) %>% dapply(\(x) unclass(x) == 1L | unclass(x) == 3L) %>% rm_stub("Type_") %>% add_stub("_Nat", pre = FALSE)
tfm(FR21) <- FR21 %>% slt(Type_ER:Type_DR) %>% dapply(\(x) unclass(x) > 1L) %>% rm_stub("Type_") %>% add_stub("_SN", pre = FALSE)
FR21 %<>% colorder(CID:DR, ER_Nat:DR_SN)

FR21_Africa <- FR21 %>% 
  fmutate(ISO3 = countrycode::countryname(Country, "iso3c")) %>% 
  fsubset(ISO3 %in% am_countries$ISO3) %>% 
  colorder(ISO3)

funique(FR21_Africa$ISO3)

FR21_Africa %>% qsu(pid = ~ ISO3, cols = .c(ER, RR, BBR, DR))

FR21_Africa_Agg <- FR21_Africa %>% 
  fgroup_by(Year) %>% 
  fselect(ER:DR_SN, N_Num_All, N_Num_Nat, Enf_OG_Nat_ER:Enf_F_SN_DR) %>% 
  replace_NA() %>% 
  fsum() %>% dapply(as.integer) 

# To see which are enforced..
FR21_Africa %>% fgroup_by(Year) %>% num_vars() %>% fmax()

# Date of first introduction
FR21_Africa_implyear <- FR21_Africa %>% 
  roworder(ISO3, Year) %>% 
  fgroup_by(ISO3, Country) %>% 
  fsummarise(across(ER:DR_SN, \(x, y) if(anyv(x, 1)) y[which.max(x)] else NA, y = Year)) %>% # %>% View()
  fmutate(min_year = do.call(pmin, c(., list(na.rm = TRUE))))

# Overall Rules
FR21_Africa_Agg %$% plot(Year, N_Num_All, type = "l")
FR21_Africa_Agg %$% plot(Year, N_Num_Nat, type = "l")

# Rules in place by type...
FR21_Africa_Agg %>% 
  fsubset(Year >= 1990, 1:5) %>% 
  frename(ER = Expenditure, RR = Revenue, BBR = "Budget Balance", DR = Debt) %>%
  qDT() %>% 
  melt(1, variable.name = "Type") %>% 
  ggplot(aes(x = Year, y = value, colour = Type)) + 
  geom_line() + 
  # scale_y_continuous(labels = scales::percent) +
  labs(title = "Fiscal Rules in Africa, 1990-2021", 
       y = "Number of African Countries Subject to a Rule", x = "Year", 
       caption = "Data Source: IMF Fiscal Rules Dataset, 2022") + 
  pretty_plot()

dev.copy(pdf, "Figures/African_Fiscal_Rules.pdf", width = 8, height = 4.5)
dev.off()

# Figure C25: By type and national
FR21_Africa_Agg %>% fsubset(Year >= 1995, Year:DR_SN) %>% 
  replace_NA() %>% roworder(Year) %>% qDT() %>% 
  melt("Year", measure = patterns("^ER", "^RR", "^BBR", "^DR"), 
       variable.name = "Institution",
       value.name = c("ER", "RR", "BBR", "DR")) %>% 
  tfm(Institution = structure(Institution, levels = c("Any", "National", "Supranational"), 
                              class = "factor")) %>% 
  frename(ER = Expenditure, RR = Revenue, BBR = "Budget Balance", DR = Debt) %>%
  melt(1:2, variable.name = "Type") %>% 
  ggplot(aes(x = Year, y = value, colour = Type)) + 
  geom_line() + facet_wrap( ~ Institution, scales = "free_y") +
  labs(title = "Fiscal Rules in Africa, 1995-2021", 
       y = "Number of African Countries Subject to a Rule", x = "Year", 
       caption = "Data Source: IMF Fiscal Rules Dataset, 2022") + 
  pretty_plot(caption.hjust = -0.03)

dev.copy(pdf, "Figures/African_Fiscal_Rules_NSN.pdf", width = 10, height = 4.5)
dev.off()

# Disaggregated
# Figure D2 (separate online Appendix D)
FR21_Africa %>% 
  fsubset(Year >= 1990, Country, Year, Expenditure = ER, Revenue = RR, "Budget Balance" = BBR, Debt = DR) %>% 
  qDT() %>% 
  melt(1:2, variable.name = "Type") %>% 
  ggplot(aes(x = Year, y = value, fill = Type)) + 
  geom_area(position = "stack") + facet_wrap(~Country) +
  # scale_y_continuous(labels = scales::percent) +
  labs(title = "Fiscal Rules in Africa, 1990-2021", 
       y = "Rule Dummy", x = "Year", 
       caption = "Data Source: IMF Fiscal Rules Dataset, 2021") + 
  pretty_plot()

dev.copy(pdf, "Figures/African_Fiscal_Rules_Countries.pdf", width = 11.69, height = 8.27)
dev.off()

# Effects of Fiscal Rules?
v <- .c(BCA_NGDPD, GGXCNL_NGDP, GGXWDG_NGDP)
DATA_Africa %>% gv(v) %>% qsu(vlabels = TRUE)

# Figure C26: Important Macroeconomic and Fiscal Aggregates
DATA_Africa %>%
  fsubset(Year >= 1981 & Year <= 2019, 
          "Year", GDP = "NY_GDP_MKTP_CD", POP = "SP_POP_TOTL", v) %>%
  na_omit(c("GDP", "POP")) %>% 
  fgroup_by(Year) %>% {
    list(None = slt(., -GDP, -POP) %>% fmedian(),
         GDP = slt(., -POP) %>% fmedian(GDP, keep.w = FALSE), 
         POP = slt(., -GDP) %>% fmedian(POP, keep.w = FALSE))
  } %>% unlist2d("Weights", DT = TRUE, id.factor = TRUE) %>%  
  fgroup_by(Weights) %>% 
  fmutate(across(v, frollmean, 10)) %>% 
  fungroup() %>% 
  set_names(c("Weights", "Year", "Current Account Balance", 
              "Government Budget Balance", "Government Gross Debt")) %>% 
  melt(1:2, na.rm = TRUE) %>% 
  ggplot(aes(x = Year, y = value, colour = Weights)) + 
  geom_line() +
  scale_y_continuous(n.breaks = 8) +
  facet_wrap(~variable, scales = "free_y") + 
  labs(y = "% of GDP: 10-Year MA of Country Medians", 
       caption = "Data Source: IMF World Economic Outlook, October 2021") +
  pretty_plot(caption.hjust = -0.03)

dev.copy(pdf, "Figures/Key_Aggregates_Africa_Weighted.pdf", width = 11.27, height = 4.3) 
dev.off()


# Creating Panel
setdiff(FR21_Africa$ISO3, DATA_Africa$ISO3)

FR21_DATA_Africa <- DATA_Africa %>% 
  fselect(Country, ISO2, ISO3, Year, GDPCGR, GDPCGR_WB, INFL, INFL_WB, CAB = BCA_NGDPD, FB = GGXCNL_NGDP, 
          PFB = GGXONLB_NGDP, GDBT = GGXWDG_NGDP, NDBT = GGXWDN_NGDP, GNS = NGSD_NGDP) %>% 
  merge(qDT(FR21_Africa) %>% fselect(-CID, -Country), by = c("ISO3", "Year")) %>% 
  roworder(ISO3, Year)

namlab(FR21_DATA_Africa) %>% ss(1:15)

settfm(FR21_DATA_Africa, 
       Any_Rule = N_Num_All > 0, 
       Nat_Rule = N_Num_Nat > 0)

# Check
FR21_DATA_Africa %$% cor(unclass(qF(N_Num_Any)), Any_Rule)

# Rolling panel:
N <- 10
FR21_DATA_Africa_roll <- FR21_DATA_Africa %>%
  roworder(ISO3, Year) %>% 
  fgroup_by(ISO3) %>%
  fmutate(across(GDPCGR:INFL_WB, list(mean = frollmean, 
                                      median = \(x, n) frollapply(x, n, median), 
                                      sd = \(x, n) frollapply(x, n, sd), 
                                      iqr = \(x, n) frollapply(x, n, IQR), 
                                      mad = \(x, n) frollapply(x, n, MAD)), N),
          across(c(ER:DR, N_Num_All, N_Num_Nat, Any_Rule, Nat_Rule), frollmean, N)) %>%
  fungroup() %>%
  fsubset(is.finite(GDPCGR_mad) | is.finite(INFL_mad))

print(pwcor(gvr(FR21_DATA_Africa_roll, "WB"), gvr(FR21_DATA_Africa_roll, "L_m|R_m")), digits = 4)

# # Rolling estimates
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ Any_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ Nat_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ Any_Rule + Nat_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ N_Num_All | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ N_Num_Nat | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ N_Num_All + N_Num_Nat | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ BBR + DR | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ Any_Rule + BBR + DR | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_median, INFL_median, GDPCGR_mad, INFL_mad) ~ Any_Rule + (BBR + DR)*Nat_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# # Using WB Data
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ Any_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ Nat_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ Any_Rule + Nat_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ N_Num_All | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ N_Num_Nat | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ N_Num_All + N_Num_Nat | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ BBR + DR | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ Any_Rule + BBR + DR | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 
# feols(c(GDPCGR_WB_median, INFL_WB_median, GDPCGR_WB_mad, INFL_WB_mad) ~ Any_Rule + (BBR + DR)*Nat_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1999) %>% etable() 

# DID2S
# library(did2s)
# did2s(FR21_DATA_Africa_roll %>% tfm(AR = Any_Rule >= 0.5), 
#       yname = "GDPCGR_mad", 
#       treatment = "AR",
#       cluster_var = "ISO3",
#       first_stage = ~ 0 | ISO3 + Year,
#       second_stage = ~ i(AR, ref=FALSE))

# Manual 2SFE: Same as above (except for SE)
mod <- FR21_DATA_Africa_roll %>% 
  fsubset(Any_Rule < 0.5) %>%
  feols(GDPCGR_mad ~ 0 | ISO3 + Year)

FR21_DATA_Africa_roll %>% 
  tfm(GDPCGR_mad = GDPCGR_mad - predict(mod, newdata = .), 
      AR = Any_Rule >= 0.5) %>% 
  feols(GDPCGR_mad ~ -1 + i(AR, ref=FALSE))

# Manual 2SFE: No dummy
mod <- FR21_DATA_Africa_roll %>% 
  fsubset(Any_Rule <= 0.01) %>%
  feols(GDPCGR_mad ~ 0 | ISO3 + Year)

FR21_DATA_Africa_roll %>% 
  tfm(GDPCGR_mad = GDPCGR_mad - predict(mod, newdata = .), 
      AR = Any_Rule > 0.01) %>% 
  feols(GDPCGR_mad ~ -1 + i(AR, ref=FALSE))



# Table C16 (In 3 Parts)
feols(c(GDPCGR_mad, INFL_mad) ~ Any_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, 
      panel.id = .c(ISO3, Year), subset = ~ Year >= 1999 & Year < 2020) %>% 
  get_vars(c(1,3,5,2,4,6)) %>%
  esttex(fixef_sizes = TRUE, vcov = "DK", 
         fixef_sizes.simplify = FALSE, digits.stats = 3,
         title = "Panel-Regression in Rolling-10-Year Panel")

feols(c(GDPCGR_mad, INFL_mad) ~ N_Num_All | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, 
      panel.id = .c(ISO3, Year), subset = ~ Year >= 1999 & Year < 2020) %>% 
  get_vars(c(1,3,5,2,4,6)) %>%
  esttex(fixef_sizes = TRUE, vcov = "DK",
         fixef_sizes.simplify = FALSE, digits.stats = 3,
         title = "Panel-Regression in Rolling-10-Year Panel")

feols(c(GDPCGR_mad, INFL_mad) ~ ER + RR + BBR + DR | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, 
      panel.id = .c(ISO3, Year), subset = ~ Year >= 1999 & Year < 2020) %>% 
  get_vars(c(1,3,5,2,4,6)) %>%
  esttex(fixef_sizes = TRUE, vcov = "DK",
         fixef_sizes.simplify = FALSE, digits.stats = 3,
         title = "Panel-Regression in Rolling-10-Year Panel")



# Now estimates with balances (in % of GDP) -------------------------------------
feols(c(CAB, FB, GDBT) ~ csw(Any_Rule, Nat_Rule) | csw(, Country, Year), data = FR21_DATA_Africa, subset = ~ Year >= 1990) %>% etable()
feols(c(CAB, FB, GDBT) ~ csw(N_Num_All, N_Num_Nat) | csw(, Country, Year), data = FR21_DATA_Africa, subset = ~ Year >= 1990) %>% etable()
feols(c(CAB, FB, GDBT) ~ Any_Rule + BBR + DR | csw(, Country, Year), data = FR21_DATA_Africa, subset = ~ Year >= 1990) %>% etable()
feols(c(CAB, FB, GDBT) ~ BBR + DR | csw(, Country, Year), data = FR21_DATA_Africa, subset = ~ Year >= 1990) %>% etable()

# Checking obs...
FR21_DATA_Africa %>% fselect(ISO3, Year, CAB, FB, GDBT, Any_Rule, N_Num_All) %>% qsu()

# Table C17 (In 3 Parts)
feols(c(CAB, FB, GDBT) ~ Any_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa, 
      panel.id = .c(ISO3, Year), subset = ~ Year >= 1990 & Year < 2020) %>%
  get_vars(c(1,4,7,2,5,8,3,6,9)) %>% 
  esttex(fixef_sizes = TRUE, vcov = "DK",
         fixef_sizes.simplify = FALSE, digits.stats = 3,
         title = "Panel-Regression in 30-Year Panel")
# feols(c(CAB, FB, GDBT) ~ Any_Rule + Nat_Rule | csw(, ISO3, Year), data = FR21_DATA_Africa_roll, subset = ~ Year >= 1990 & Year < 2020)

feols(c(CAB, FB, GDBT) ~ N_Num_All | csw(, ISO3, Year), data = FR21_DATA_Africa, 
      panel.id = .c(ISO3, Year), subset = ~ Year >= 1990 & Year < 2020) %>% 
  get_vars(c(1,4,7,2,5,8,3,6,9)) %>% 
  esttex(fixef_sizes = TRUE, vcov = "DK",
         fixef_sizes.simplify = FALSE, digits.stats = 3,
         title = "Panel-Regression in 30-Year Panel")

feols(c(CAB, FB, GDBT) ~ ER + RR + BBR + DR | csw(, ISO3, Year), data = FR21_DATA_Africa, 
      panel.id = .c(ISO3, Year), subset = ~ Year >= 1990 & Year < 2020) %>% 
  get_vars(c(1,4,7,2,5,8,3,6,9)) %>% 
  esttex(fixef_sizes = TRUE, vcov = "DK",
         fixef_sizes.simplify = FALSE, digits.stats = 3,
         title = "Panel-Regression in 30-Year Panel")


